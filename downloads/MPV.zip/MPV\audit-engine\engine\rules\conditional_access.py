from ..model import fail, na, ok, unknown, warn
from ..registry import rule

CA_NEED = [("ca", "conditionalAccessPolicies")]


def _secdef(snap):
    return snap.identity.summary.get("security_defaults_enabled")


def _ca_gate(snap):
    """Trả (outcome|None, mode). mode: 'secdef' = Security Defaults đang bật; 'ca' = đọc được CA;
    'no_ca' = tenant không có CA (Free) và Security Defaults tắt -> không có cơ chế bắt buộc nào."""
    if _secdef(snap) is True:
        return ok({"security_defaults_enabled": True}, "Security Defaults đang bật (bắt buộc MFA, chặn legacy auth)"), "secdef"
    st = snap.ca.state("conditionalAccessPolicies")
    if st == "ok":
        return None, "ca"
    if st == "license" and _secdef(snap) is False:
        return None, "no_ca"
    return unknown(f"Không đọc được Conditional Access (state={st}) và không rõ Security Defaults"), "unknown"


@rule(id="CA-001", domain="ConditionalAccess", title="Không có policy bắt buộc MFA cho mọi người dùng / mọi ứng dụng", severity="High",
      risk="Không có lớp bắt buộc MFA nhất quán, tài khoản chỉ dựa vào mật khẩu.",
      remediation=["Tạo CA policy: All users, All cloud apps, Grant = Require MFA (hoặc authentication strength)",
                   "Loại trừ tối thiểu: 2 break-glass account", "Triển khai ở report-only 1-2 tuần rồi bật"],
      effort="Medium", frameworks=["CIS M365 Foundations - MFA cho tất cả người dùng"],
      sources=["ca", "identity"], tags=["mfa", "conditional-access"])
def ca_001(snap):
    early, mode = _ca_gate(snap)
    if mode in ("secdef", "unknown"):
        return early
    if mode == "no_ca":
        return fail({"conditional_access": "unavailable", "security_defaults_enabled": False},
                    "Tenant không có Conditional Access (license) và Security Defaults đang tắt -> không có cơ chế bắt buộc MFA")
    s = snap.ca.summary
    ev = {"policies_enabled": s.get("policies_enabled"), "mfa_all_users_all_apps": s.get("mfa_all_users_all_apps")}
    return ok(ev) if s.get("mfa_all_users_all_apps") else fail(ev, "Không có policy enabled nào yêu cầu MFA cho All users + All apps")


@rule(id="CA-002", domain="ConditionalAccess", title="Legacy authentication chưa bị chặn", severity="High",
      risk="Giao thức legacy (IMAP/POP/SMTP...) không hỗ trợ MFA nên bị dùng để password spray vượt MFA.",
      remediation=["Tạo CA policy: All users, Client apps = Exchange ActiveSync + Other clients, Grant = Block",
                   "Dùng sign-in log (BL-006) để tìm ứng dụng còn dùng legacy trước khi chặn", "Tắt Basic Auth ở Exchange Online/SMTP AUTH nếu không cần"],
      effort="Medium", frameworks=["CIS M365 Foundations - chặn legacy authentication"],
      sources=["ca", "identity", "baseline"], tags=["legacy-auth", "conditional-access"])
def ca_002(snap):
    early, mode = _ca_gate(snap)
    if mode in ("secdef", "unknown"):
        return early
    mfa_all = snap.ca.summary.get("mfa_all_users_all_apps") if mode == "ca" else False
    ev = {"legacy_auth_blocked_all_users": snap.ca.summary.get("legacy_auth_blocked_all_users") if mode == "ca" else False,
          "mfa_all_users_all_apps": mfa_all}
    if ev["legacy_auth_blocked_all_users"]:
        return ok(ev)
    # Leo thang: legacy chưa chặn VÀ MFA cũng không bắt buộc cho mọi người -> nguy cơ chiếm tài khoản rất cao
    sev = "Critical" if mfa_all is False else "High"
    return fail(ev, "Không có policy chặn legacy auth cho tất cả người dùng", severity=sev)


@rule(id="CA-003", domain="ConditionalAccess", title="Không có policy bắt buộc MFA cho vai trò quản trị", severity="High",
      risk="Tài khoản quản trị là mục tiêu số một; thiếu MFA bắt buộc cho admin là rủi ro nghiêm trọng nhất.",
      remediation=["Tạo CA policy cho Directory roles: Require phishing-resistant MFA (authentication strength)",
                   "Loại trừ break-glass bằng nhóm riêng, giám sát đăng nhập của nhóm này"],
      effort="Low", frameworks=["CIS M365 Foundations - MFA cho vai trò quản trị"],
      sources=["ca", "identity"], tags=["mfa", "privileged", "conditional-access"])
def ca_003(snap):
    early, mode = _ca_gate(snap)
    if mode in ("secdef", "unknown"):
        return early
    if mode == "no_ca":
        return fail({"conditional_access": "unavailable"}, "Không có Conditional Access và Security Defaults tắt")
    v = snap.ca.summary.get("mfa_covers_admin_roles")
    ev = {"mfa_covers_admin_roles": v}
    return ok(ev) if v else fail(ev, "Không có policy enabled yêu cầu MFA nhắm vào admin roles hoặc All users")


@rule(id="CA-004", domain="ConditionalAccess", title="Policy ở trạng thái report-only hoặc disabled tồn đọng", severity="Low",
      risk="Policy không được thực thi tạo cảm giác an toàn giả; policy cũ làm cấu hình khó hiểu.",
      remediation=["Rà soát từng policy: bật, sửa hoặc xóa", "Đặt hạn cho giai đoạn report-only"],
      effort="Low", frameworks=["Quản trị cấu hình CA"], sources=["ca"], needs=CA_NEED, tags=["hygiene", "conditional-access"])
def ca_004(snap):
    s = snap.ca.summary
    ro, dis = s.get("policies_report_only", 0), s.get("policies_disabled", 0)
    ev = {"report_only": ro, "disabled": dis, "enabled": s.get("policies_enabled")}
    if ro + dis == 0:
        return ok(ev)
    names = [f["name"] for f in snap.ca.data.get("facts", []) if f.get("state") != "enabled"]
    return warn(ev, f"{ro} policy report-only, {dis} policy disabled", affected=names)


@rule(id="CA-005", domain="ConditionalAccess", title="Policy đang bật có loại trừ người dùng/nhóm", severity="Medium",
      risk="Nhóm loại trừ thường phình to theo thời gian và trở thành lỗ hổng bỏ qua MFA.",
      remediation=["Chỉ loại trừ 2 break-glass account qua nhóm riêng", "Review thành viên nhóm loại trừ hàng quý",
                   "Tránh loại trừ trực tiếp từng user"],
      effort="Low", frameworks=["Quản trị cấu hình CA"], sources=["ca"], needs=CA_NEED, tags=["conditional-access", "exclusions"])
def ca_005(snap):
    facts = [f for f in snap.ca.data.get("facts", []) if f.get("state") == "enabled" and f.get("has_exclusions")]
    ev = {"enabled_policies_with_exclusions": len(facts),
          "direct_user_exclusions_total": sum(f.get("excluded_users_count", 0) for f in facts)}
    if not facts:
        return ok(ev)
    return warn(ev, "Cần xác nhận mỗi loại trừ có lý do và chủ sở hữu", affected=[f["name"] for f in facts])


@rule(id="CA-006", domain="ConditionalAccess", title="Chưa có policy theo sign-in risk / user risk", severity="Medium",
      risk="Không tự động phản ứng với đăng nhập rủi ro cao (token theft, leaked credentials).",
      remediation=["Tạo CA: sign-in risk Medium+ => Require MFA", "Tạo CA: user risk High => Require password change"],
      effort="Medium", frameworks=["Microsoft Entra ID Protection"], sources=["ca", "identity"], needs=CA_NEED, tags=["identity-protection"])
def ca_006(snap):
    if snap.identity.state("riskyUsers") == "license":
        return na("Tenant không có Entra ID P2 (Identity Protection)")
    s = snap.ca.summary
    ev = {"sign_in_risk_policy_enabled": s.get("sign_in_risk_policy_enabled"), "user_risk_policy_enabled": s.get("user_risk_policy_enabled")}
    return ok(ev) if (ev["sign_in_risk_policy_enabled"] and ev["user_risk_policy_enabled"]) else warn(ev, "Thiếu policy theo risk")


@rule(id="CA-007", domain="ConditionalAccess", title="Không yêu cầu thiết bị tuân thủ/hybrid join cho truy cập", severity="Low",
      risk="Dữ liệu công ty có thể truy cập từ thiết bị không được quản lý.",
      remediation=["Bắt buộc compliant device cho ứng dụng nhạy cảm (Exchange, SharePoint)", "Bắt đầu với admin và nhóm rủi ro cao"],
      effort="High", frameworks=["Zero Trust - device trust"], sources=["ca"], needs=CA_NEED, tags=["devices", "conditional-access"])
def ca_007(snap):
    v = snap.ca.summary.get("device_compliance_required")
    ev = {"device_compliance_required": v}
    return ok(ev) if v else warn(ev, "Không có policy enabled yêu cầu compliant/hybrid joined device (cần xác nhận phù hợp mô hình Intune của khách)")


@rule(id="CA-008", domain="ConditionalAccess", title="Đăng ký thông tin bảo mật (MFA registration) chưa được bảo vệ", severity="Medium",
      risk="Kẻ tấn công có mật khẩu có thể tự đăng ký MFA của chúng.",
      remediation=["CA policy cho user action 'Register security information': yêu cầu MFA hoặc vị trí tin cậy/TAP"],
      effort="Low", frameworks=["Microsoft Entra - protect security info registration"], sources=["ca"], needs=CA_NEED, tags=["mfa", "conditional-access"])
def ca_008(snap):
    v = snap.ca.summary.get("security_info_registration_protected")
    ev = {"security_info_registration_protected": v}
    return ok(ev) if v else warn(ev, "Không có policy bảo vệ thao tác đăng ký security info")


@rule(id="CA-009", domain="ConditionalAccess", title="Guest/external user không bị bắt buộc MFA", severity="Medium",
      risk="Tài khoản khách bị chiếm cho phép truy cập dữ liệu chia sẻ của tổ chức.",
      remediation=["CA policy: Guest or external users => Require MFA", "Cân nhắc cross-tenant access trust MFA từ tenant đối tác"],
      effort="Low", frameworks=["CIS M365 Foundations - external users"], sources=["ca", "identity"], needs=CA_NEED, tags=["guests", "mfa"])
def ca_009(snap):
    if (snap.identity.summary.get("guests") or 0) == 0:
        return na("Tenant không có guest")
    v = snap.ca.summary.get("mfa_for_guests")
    ev = {"guests": snap.identity.summary.get("guests"), "mfa_for_guests": v}
    return ok(ev) if v else warn(ev, "Có guest nhưng không có policy MFA nhắm vào guest/All users")
