#Requires -Version 7.0
<#
.SYNOPSIS
  Collector 2 - Conditional Access: policy thô + các "facts" suy ra (MFA, block legacy auth, risk,
  device compliance, guests, exclusions), named locations, authentication strengths.
.NOTES
  Quyền Graph (Application, read-only): Policy.Read.All
  Cần Entra ID P1 để đọc Conditional Access (thiếu license -> mục errors, hint=license).
#>
[CmdletBinding()]
param(
    [string]$TenantId,
    [string]$ClientId,
    [string]$OutDir,
    [switch]$Pseudonymize
)
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot 'AuditCommon.psm1') -ErrorAction Stop
Start-AuditCollector -TenantId $TenantId -ClientId $ClientId -OutDir $OutDir -Pseudonymize:$Pseudonymize `
    -Permissions 'Policy.Read.All'

Write-Host '[02] Conditional Access collector...' -ForegroundColor Cyan

$GLOBAL_ADMIN_TEMPLATE_ID = '62e90394-69f5-4237-9190-012177145e10'

$policies  = Invoke-GraphSafe -Name 'conditionalAccessPolicies' -Paged -Uri '/v1.0/identity/conditionalAccess/policies'
$locations = Invoke-GraphSafe -Name 'namedLocations' -Paged -Uri '/v1.0/identity/conditionalAccess/namedLocations'
$strengths = Invoke-GraphSafe -Name 'authenticationStrengths' -Paged -Uri '/v1.0/policies/authenticationStrengthPolicies'

function Get-PolicyFacts {
    param($p)
    $c = $p.conditions
    $g = $p.grantControls
    $s = $p.sessionControls

    $builtIn     = ConvertTo-AuditArray $g.builtInControls
    $clientTypes = ConvertTo-AuditArray $c.clientAppTypes
    $incUsers    = ConvertTo-AuditArray $c.users.includeUsers
    $incRoles    = ConvertTo-AuditArray $c.users.includeRoles
    $incApps     = ConvertTo-AuditArray $c.applications.includeApplications
    $userActions = ConvertTo-AuditArray $c.applications.includeUserActions
    $exclUsers   = ConvertTo-AuditArray $c.users.excludeUsers
    $exclGroups  = ConvertTo-AuditArray $c.users.excludeGroups
    $exclRoles   = ConvertTo-AuditArray $c.users.excludeRoles
    $userRisk    = ConvertTo-AuditArray $c.userRiskLevels
    $signInRisk  = ConvertTo-AuditArray $c.signInRiskLevels
    $exclLoc     = ConvertTo-AuditArray $c.locations.excludeLocations
    $incLoc      = ConvertTo-AuditArray $c.locations.includeLocations
    $platforms   = ConvertTo-AuditArray $c.platforms.includePlatforms

    $blocks      = ('block' -in $builtIn)
    $legacyTypes = (('exchangeActiveSync' -in $clientTypes) -or ('other' -in $clientTypes))
    $modernTypes = (('browser' -in $clientTypes) -or ('mobileAppsAndDesktopClients' -in $clientTypes))

    [ordered]@{
        id                         = $p.id
        name                       = $p.displayName
        state                      = $p.state   # enabled | disabled | enabledForReportingButNotEnforced
        created                    = $p.createdDateTime
        modified                   = $p.modifiedDateTime
        targets_all_users          = ('All' -in $incUsers)
        targets_guests             = [bool]$c.users.includeGuestsOrExternalUsers
        targets_directory_roles    = ($incRoles.Count -gt 0)
        include_roles_count        = $incRoles.Count
        targets_global_admin       = ($GLOBAL_ADMIN_TEMPLATE_ID -in $incRoles)
        targets_all_apps           = ('All' -in $incApps)
        targets_user_actions       = $userActions
        protects_security_info_registration = ('urn:user:registersecurityinfo' -in $userActions)
        client_app_types           = $clientTypes
        platforms_included         = $platforms
        requires_mfa               = (('mfa' -in $builtIn) -or [bool]$g.authenticationStrength)
        authentication_strength    = $g.authenticationStrength.displayName
        blocks_access              = $blocks
        blocks_legacy_auth         = ($blocks -and $legacyTypes -and -not $modernTypes)
        requires_compliant_device  = ('compliantDevice' -in $builtIn)
        requires_hybrid_joined     = ('domainJoinedDevice' -in $builtIn)
        requires_approved_or_compliant_app = (('approvedApplication' -in $builtIn) -or ('compliantApplication' -in $builtIn))
        requires_password_change   = ('passwordChange' -in $builtIn)
        grant_operator             = $g.operator   # OR = chỉ cần đáp ứng 1 control
        user_risk_levels           = $userRisk
        sign_in_risk_levels        = $signInRisk
        uses_risk_conditions       = (($userRisk.Count + $signInRisk.Count) -gt 0)
        excluded_users_count       = $exclUsers.Count
        excluded_groups_count      = $exclGroups.Count
        excluded_roles_count       = $exclRoles.Count
        has_exclusions             = (($exclUsers.Count + $exclGroups.Count + $exclRoles.Count) -gt 0)
        includes_locations         = $incLoc
        excludes_locations         = $exclLoc
        excludes_trusted_locations = ('AllTrusted' -in $exclLoc)
        uses_device_filter         = [bool]$c.devices.deviceFilter
        sign_in_frequency_enabled  = [bool]$s.signInFrequency.isEnabled
        persistent_browser_mode    = $s.persistentBrowser.mode
    }
}

$facts = @()
if ($null -ne $policies) { $facts = @($policies | ForEach-Object { Get-PolicyFacts $_ }) }
$enabled = @($facts | Where-Object { $_.state -eq 'enabled' })

$summary = [ordered]@{
    policies_total                 = $facts.Count
    policies_enabled               = $enabled.Count
    policies_report_only           = @($facts | Where-Object { $_.state -eq 'enabledForReportingButNotEnforced' }).Count
    policies_disabled              = @($facts | Where-Object { $_.state -eq 'disabled' }).Count
    mfa_all_users_all_apps         = (@($enabled | Where-Object { $_.targets_all_users -and $_.targets_all_apps -and $_.requires_mfa -and -not $_.blocks_access }).Count -gt 0)
    mfa_covers_admin_roles         = (@($enabled | Where-Object { $_.requires_mfa -and -not $_.blocks_access -and ($_.targets_directory_roles -or $_.targets_all_users) }).Count -gt 0)
    mfa_for_guests                 = (@($enabled | Where-Object { $_.requires_mfa -and ($_.targets_guests -or $_.targets_all_users) }).Count -gt 0)
    legacy_auth_blocked_all_users  = (@($enabled | Where-Object { $_.blocks_legacy_auth -and $_.targets_all_users }).Count -gt 0)
    security_info_registration_protected = (@($enabled | Where-Object { $_.protects_security_info_registration }).Count -gt 0)
    sign_in_risk_policy_enabled    = (@($enabled | Where-Object { $_.sign_in_risk_levels.Count -gt 0 }).Count -gt 0)
    user_risk_policy_enabled       = (@($enabled | Where-Object { $_.user_risk_levels.Count -gt 0 }).Count -gt 0)
    device_compliance_required     = (@($enabled | Where-Object { $_.requires_compliant_device -or $_.requires_hybrid_joined }).Count -gt 0)
    enabled_policies_with_exclusions = @($enabled | Where-Object { $_.has_exclusions }).Count
    enabled_policies_using_or_operator = @($enabled | Where-Object { $_.grant_operator -eq 'OR' -and $_.requires_mfa }).Count
    named_locations_count          = if ($null -ne $locations) { $locations.Count } else { $null }
}

$locRecords = $null
if ($null -ne $locations) {
    $locRecords = @($locations | ForEach-Object {
            [ordered]@{
                id           = $_.id
                name         = $_.displayName
                type         = ($_.'@odata.type' -replace '^#microsoft\.graph\.', '')
                is_trusted   = $_.isTrusted
                countries    = $_.countriesAndRegions
                ip_range_count = (Get-AuditCount $_.ipRanges)
            }
        })
}
$strRecords = $null
if ($null -ne $strengths) {
    $strRecords = @($strengths | ForEach-Object {
            [ordered]@{
                id                    = $_.id
                name                  = $_.displayName
                policy_type           = $_.policyType
                allowed_combinations  = $_.allowedCombinations
            }
        })
}

$data = [ordered]@{
    facts                   = $facts
    policies_raw            = $policies
    named_locations         = $locRecords
    authentication_strengths = $strRecords
}
$notes = @(
    'facts là dữ kiện suy ra từ policy, KHÔNG phải kết luận. Rules engine sẽ đánh giá.',
    'Policy "All users" thường loại trừ break-glass - collector không tự xác định được break-glass; cần người xác nhận.',
    'Policy report-only hoặc disabled kéo dài là điểm cần rà soát.',
    'includeRoles chứa roleTemplateId, đối chiếu tên role ở snapshot 03.'
)
$result = Save-AuditSnapshot -Domain 'ConditionalAccess' -Name '02_conditional_access' -Data $data -Summary $summary -Notes $notes `
    -Sources @('/v1.0/identity/conditionalAccess/policies', '/v1.0/identity/conditionalAccess/namedLocations', '/v1.0/policies/authenticationStrengthPolicies')
Write-Host ("    -> {0} policy ({1} enabled), {2} lỗi/cảnh báo" -f $summary.policies_total, $summary.policies_enabled, $result.ErrorCount)
$result
