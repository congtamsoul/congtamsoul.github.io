﻿#Requires -Version 7.0
<#
  AuditCommon.psm1 - hàm dùng chung cho các collector.
  Nguyên tắc: CHỈ gọi GET (read-only). Không ghi bất cứ thứ gì vào tenant.
  Yêu cầu: module Microsoft.Graph.Authentication (v2.x)
           Install-Module Microsoft.Graph.Authentication -Scope CurrentUser -Force
#>

function Import-AuditGraphModule {
    $moduleName = 'Microsoft.Graph.Authentication'
    $paths = @()
    foreach ($p in ($env:PSModulePath -split ';')) {
        if ($p) { $paths += $p }
    }
    $extra = @(
        (Join-Path $HOME 'Documents\PowerShell\Modules'),
    )
    foreach ($p in $extra) { if ($p -and -not ($paths -contains $p)) { $paths += $p } }

    foreach ($base in $paths) {
        $candidate = Join-Path $base $moduleName
        if (Test-Path $candidate) {
            $psd1 = Get-ChildItem -Path $candidate -Filter '*.psd1' -Recurse -File | Select-Object -First 1
            if ($psd1) {
                Import-Module $psd1.FullName -Force -ErrorAction Stop
                return
            }
        }
    }

    try {
        Import-Module $moduleName -Force -ErrorAction Stop
        return
    }
    catch {
        Write-Error "Thiếu module Microsoft.Graph.Authentication. Hãy chạy: Install-Module Microsoft.Graph.Authentication -Scope CurrentUser -Force; rồi chạy lại script."
        throw
    }
}

Import-AuditGraphModule

$script:State = @{
    TenantId         = $null
    OutDir           = $null
    Pseudonymize     = $false
    AliasMap         = @{}
    AliasCount       = @{}
    Errors           = [System.Collections.Generic.List[object]]::new()
    UserCache        = $null
    SignInActivityOk = $false
    LastTruncated    = $false
}

function Get-AuditCredentialFilePath {
    $folder = Join-Path $PSScriptRoot '.audit-secrets'
    $null = New-Item -ItemType Directory -Path $folder -Force -ErrorAction SilentlyContinue
    return Join-Path $folder 'm365-audit-credentials.json'
}

function Protect-AuditSecret {
    param([Parameter(Mandatory)][string]$PlainText)
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($PlainText)
    $protected = [System.Security.Cryptography.ProtectedData]::Protect($bytes, $null, [System.Security.Cryptography.DataProtectionScope]::CurrentUser)
    return [Convert]::ToBase64String($protected)
}

function Unprotect-AuditSecret {
    param([Parameter(Mandatory)][string]$ProtectedBase64)
    try {
        $bytes = [Convert]::FromBase64String($ProtectedBase64)
        $plain = [System.Security.Cryptography.ProtectedData]::Unprotect($bytes, $null, [System.Security.Cryptography.DataProtectionScope]::CurrentUser)
        return [System.Text.Encoding]::UTF8.GetString($plain)
    }
    catch {
        throw "Không đọc được secret đã mã hóa. Có thể do user profile khác hoặc file bị hỏng. $_"
    }
}

function Save-AuditCredentials {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$TenantId,
        [Parameter(Mandatory)][string]$ClientId,
        [Parameter(Mandatory)][securestring]$ClientSecret
    )

    $bstr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($ClientSecret)
    try {
        $plain = [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr)
    }
    finally {
        [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)
    }

    $cfg = [ordered]@{
        tenantId   = $TenantId
        clientId   = $ClientId
        secret     = Protect-AuditSecret -PlainText $plain
        updatedAt  = [datetime]::UtcNow.ToString('o')
        encrypted  = $true
    }

    $path = Get-AuditCredentialFilePath
    $cfg | ConvertTo-Json -Depth 4 | Set-Content -Path $path -Encoding utf8
    Write-Host "Đã lưu credential mã hóa cho tenant $TenantId tại $path" -ForegroundColor Green
    return $path
}

function Get-AuditSavedCredentials {
    $path = Get-AuditCredentialFilePath
    if (-not (Test-Path $path)) { return $null }

    try {
        $obj = Get-Content -Raw -Path $path | ConvertFrom-Json
        if (-not $obj -or -not $obj.clientId -or -not $obj.tenantId -or -not $obj.secret) {
            return $null
        }
        return [pscustomobject]@{
            TenantId = [string]$obj.tenantId
            ClientId = [string]$obj.clientId
            Secret = [string]$obj.secret
        }
    }
    catch {
        Write-Warning "Không đọc được file credential đã lưu ở $path. Hãy chạy lại Setup-AuditCredentials.ps1."
        return $null
    }
}

function Get-AuditSecretFromStore {
    $saved = Get-AuditSavedCredentials
    if (-not $saved) { return $null }

    $plain = Unprotect-AuditSecret -ProtectedBase64 $saved.Secret
    return (ConvertTo-SecureString -String $plain -AsPlainText -Force)
}

#region ---------- Kết nối ----------
function Connect-AuditGraph {
    <# Kết nối Graph bằng app registration + client secret.
       Secret lấy từ:
       1) tham số -ClientSecret
       2) biến môi trường M365_CLIENT_SECRET
       3) file đã lưu mã hóa ở thư mục /MPV/.audit-secrets
       4) hỏi nhập nếu chưa có gì cả và lưu lại để lần sau không hỏi nữa #>
    [CmdletBinding()]
    param(
        [string]$TenantId,
        [string]$ClientId,
        [securestring]$ClientSecret
    )

    $saved = Get-AuditSavedCredentials
    if (-not $TenantId -and $saved) { $TenantId = $saved.TenantId }
    if (-not $ClientId -and $saved) { $ClientId = $saved.ClientId }

    if (-not $ClientSecret -and $saved) {
        $ClientSecret = Get-AuditSecretFromStore
    }

    if (-not $TenantId -or -not $ClientId) {
        throw 'Thiếu TenantId hoặc ClientId. Hãy truyền tham số, hoặc chạy Setup-AuditCredentials.ps1 một lần để lưu credential.'
    }

    if (-not $ClientSecret) {
        if ($env:M365_CLIENT_SECRET) {
            $ClientSecret = ConvertTo-SecureString $env:M365_CLIENT_SECRET -AsPlainText -Force
        }
        else {
            $ClientSecret = Read-Host "Client secret của app $ClientId" -AsSecureString
            Save-AuditCredentials -TenantId $TenantId -ClientId $ClientId -ClientSecret $ClientSecret | Out-Null
        }
    }

    $cred = [System.Management.Automation.PSCredential]::new($ClientId, $ClientSecret)
    Connect-MgGraph -TenantId $TenantId -ClientSecretCredential $cred -NoWelcome -ErrorAction Stop | Out-Null
    $script:State.TenantId  = $TenantId
    $script:State.UserCache = $null
    Get-MgContext
}

function Test-AuditPermission {
    <# Cảnh báo sớm nếu token thiếu quyền (chỉ mang tính gợi ý). #>
    param([string[]]$Required)
    $ctx = Get-MgContext
    $granted = @($ctx.Scopes)
    if ($granted.Count -eq 0 -or -not $Required) { return }
    $missing = @($Required | Where-Object { $_ -notin $granted })
    if ($missing.Count -gt 0) {
        Write-Warning ("Token có thể thiếu quyền: " + ($missing -join ', ') + " (một số endpoint có thể trả 403)")
    }
}

function Initialize-AuditRun {
    param(
        [Parameter(Mandatory)][string]$OutDir,
        [switch]$Pseudonymize
    )
    New-Item -ItemType Directory -Path $OutDir -Force | Out-Null
    $script:State.OutDir       = (Resolve-Path $OutDir).Path
    $script:State.Pseudonymize = [bool]$Pseudonymize
    $ctx = Get-MgContext
    if ($ctx -and -not $script:State.TenantId) { $script:State.TenantId = $ctx.TenantId }
}

function Start-AuditCollector {
    <# Gọi ở đầu mỗi collector: đảm bảo đã kết nối, chuẩn bị thư mục, reset danh sách lỗi. #>
    [CmdletBinding()]
    param(
        [string]$TenantId,
        [string]$ClientId,
        [string]$OutDir,
        [switch]$Pseudonymize,
        [string[]]$Permissions
    )

    $saved = Get-AuditSavedCredentials
    if (-not $TenantId -and $saved) { $TenantId = $saved.TenantId }
    if (-not $ClientId -and $saved) { $ClientId = $saved.ClientId }

    if (-not (Get-MgContext)) {
        if (-not $TenantId -or -not $ClientId) {
            throw 'Chưa kết nối Graph: cần truyền -TenantId và -ClientId, hoặc chạy Setup-AuditCredentials.ps1 để lưu credential một lần.'
        }
        $null = Connect-AuditGraph -TenantId $TenantId -ClientId $ClientId
    }
    if (-not $OutDir) {
        $tid = if ($TenantId) { $TenantId } else { $script:State.TenantId }
        $OutDir = Join-Path (Get-Location) ("snapshots/{0}/{1}" -f $tid, (Get-Date -Format 'yyyyMMdd-HHmmss'))
    }
    Initialize-AuditRun -OutDir $OutDir -Pseudonymize:$Pseudonymize
    $script:State.Errors.Clear()
    Test-AuditPermission -Required $Permissions
}
#endregion

#region ---------- Gọi Graph an toàn ----------
function Get-AuditHttpStatus {
    param($ErrorRecord)
    $ex = $ErrorRecord.Exception
    try { if ($ex.Response -and $ex.Response.StatusCode) { return [int]$ex.Response.StatusCode } } catch {}
    try { if ($ex.StatusCode) { return [int]$ex.StatusCode } } catch {}
    $text = "$($ErrorRecord.ErrorDetails.Message) $($ex.Message)"
    if ($text -match '\b(400|401|403|404|429|500|502|503|504)\b') { return [int]$Matches[1] }
    return $null
}

function Get-AuditErrorDetail {
    param($ErrorRecord)
    $msg = $ErrorRecord.ErrorDetails.Message
    if (-not $msg) { $msg = $ErrorRecord.Exception.Message }
    $code = $null
    $text = $msg
    try {
        $j = $msg | ConvertFrom-Json -ErrorAction Stop
        if ($j.error) { $code = $j.error.code; $text = $j.error.message }
    }
    catch {}
    [pscustomobject]@{ Code = $code; Message = $text }
}

function Add-AuditError {
    param([string]$Name, [string]$Uri, $ErrorRecord)
    $d      = Get-AuditErrorDetail $ErrorRecord
    $status = Get-AuditHttpStatus $ErrorRecord
    $probe  = "$($d.Code) $($d.Message)"
    $hint   = 'other'
    if ($probe -match 'NonPremium|premium|licen[sc]e') { $hint = 'license' }
    elseif ($status -eq 403 -or $probe -match 'Authorization_RequestDenied|Insufficient privileges|Forbidden') { $hint = 'permission' }
    elseif ($status -eq 404) { $hint = 'not_found' }
    $script:State.Errors.Add([pscustomobject]@{
            name        = $Name
            endpoint    = $Uri
            http_status = $status
            code        = $d.Code
            message     = $d.Message
            hint        = $hint
        })
    Write-Warning "[$Name] HTTP $status ($hint) - $($d.Code)"
}

function Invoke-GraphWithRetry {
    param(
        [Parameter(Mandatory)][string]$Uri,
        [hashtable]$Headers,
        [int]$MaxRetry = 5
    )
    $attempt = 0
    while ($true) {
        try {
            $p = @{ Method = 'GET'; Uri = $Uri; OutputType = 'Hashtable'; ErrorAction = 'Stop' }
            if ($Headers) { $p.Headers = $Headers }
            return Invoke-MgGraphRequest @p
        }
        catch {
            $attempt++
            $status = Get-AuditHttpStatus $_
            if ($status -in 429, 502, 503, 504 -and $attempt -le $MaxRetry) {
                $wait = [math]::Min(60, [math]::Pow(2, $attempt))
                try {
                    $ra = $_.Exception.Response.Headers.RetryAfter
                    if ($ra -and $ra.Delta) { $wait = [math]::Max($wait, $ra.Delta.TotalSeconds) }
                }
                catch {}
                Write-Verbose "HTTP $status - thử lại sau $wait giây (lần $attempt)"
                Start-Sleep -Seconds $wait
                continue
            }
            throw
        }
    }
}

function Invoke-GraphPaged {
    <# Đi theo @odata.nextLink. Trả về mảng (dùng: $x = Invoke-GraphPaged ...). #>
    param(
        [Parameter(Mandatory)][string]$Uri,
        [hashtable]$Headers,
        [int]$MaxPages = 0
    )
    $script:State.LastTruncated = $false
    $items = [System.Collections.Generic.List[object]]::new()
    $next = $Uri
    $page = 0
    while ($next) {
        $resp = Invoke-GraphWithRetry -Uri $next -Headers $Headers
        $page++
        if ($null -ne $resp.value) { foreach ($v in @($resp.value)) { $items.Add($v) } }
        $next = $resp.'@odata.nextLink'
        if ($next -and $MaxPages -gt 0 -and $page -ge $MaxPages) {
            $script:State.LastTruncated = $true
            break
        }
    }
    return , $items.ToArray()
}

function Get-AuditLastTruncated { return [bool]$script:State.LastTruncated }

function Invoke-GraphSafe {
    <# Bọc lỗi: thất bại -> ghi vào danh sách errors của snapshot và trả $null.
       -Paged thành công luôn trả mảng (có thể rỗng), nên kiểm tra  $null -eq $kq  để biết có lỗi. #>
    param(
        [Parameter(Mandatory)][string]$Uri,
        [Parameter(Mandatory)][string]$Name,
        [switch]$Paged,
        [int]$MaxPages = 0,
        [hashtable]$Headers
    )
    try {
        if ($Paged) {
            $r = Invoke-GraphPaged -Uri $Uri -Headers $Headers -MaxPages $MaxPages
            return , $r
        }
        return (Invoke-GraphWithRetry -Uri $Uri -Headers $Headers)
    }
    catch {
        Add-AuditError -Name $Name -Uri $Uri -ErrorRecord $_
        return $null
    }
}

function Select-AuditSingle {
    <# Một số endpoint trả object, số khác trả {value:[...]} - hàm này lấy phần tử đầu. #>
    param($Response)
    if ($null -eq $Response) { return $null }
    if ($Response -is [System.Collections.IDictionary] -and $Response.ContainsKey('value')) {
        return @($Response['value'])[0]
    }
    return $Response
}
#endregion

#region ---------- Tiện ích ----------
function ConvertTo-AuditArray {
    <# Luôn trả về mảng (null -> mảng rỗng). #>
    param($Value)
    if ($null -eq $Value) { return , @() }
    return , @($Value)
}

function Get-AuditCount {
    param($Value)
    if ($null -eq $Value) { return 0 }
    return @($Value).Count
}

function Get-AuditUniqueCount {
    <# Đếm giá trị duy nhất của khóa $Key trong danh sách hashtable (không dùng Select-Object vì hashtable không có property thật). #>
    param($Items, [string]$Key)
    return @($Items | ForEach-Object { $_[$Key] } | Where-Object { $null -ne $_ } | Sort-Object -Unique).Count
}

function ConvertTo-AuditUtcDate {
    param($Value)
    if ($null -eq $Value -or "$Value" -eq '') { return $null }
    if ($Value -is [datetime]) { return $Value.ToUniversalTime() }
    try {
        return ([datetimeoffset]::Parse([string]$Value, [cultureinfo]::InvariantCulture,
                [System.Globalization.DateTimeStyles]::AssumeUniversal)).UtcDateTime
    }
    catch { return $null }
}

function Get-AuditDaysFrom {
    param($Date)
    $d = ConvertTo-AuditUtcDate $Date
    if (-not $d) { return $null }
    return [int][math]::Floor(([datetime]::UtcNow - $d).TotalDays)
}
#endregion

#region ---------- Pseudonymize ----------
function Get-AuditAlias {
    <# Khi bật -Pseudonymize: thay UPN/tên bằng user_0001... để không đưa PII vào LLM.
       Bảng ánh xạ lưu cục bộ ở _alias_map.json (Export-AuditAliasMap). #>
    param([string]$Value, [string]$Type = 'user')
    if (-not $script:State.Pseudonymize -or [string]::IsNullOrEmpty($Value)) { return $Value }
    $key = "$Type|$($Value.ToLowerInvariant())"
    if (-not $script:State.AliasMap.ContainsKey($key)) {
        if (-not $script:State.AliasCount.ContainsKey($Type)) { $script:State.AliasCount[$Type] = 0 }
        $script:State.AliasCount[$Type]++
        $script:State.AliasMap[$key] = '{0}_{1:D4}' -f $Type, $script:State.AliasCount[$Type]
    }
    return $script:State.AliasMap[$key]
}

function Export-AuditAliasMap {
    if (-not $script:State.Pseudonymize -or $script:State.AliasMap.Count -eq 0) { return }
    $rows = foreach ($k in $script:State.AliasMap.Keys) {
        $type, $val = $k -split '\|', 2
        [pscustomobject]@{ alias = $script:State.AliasMap[$k]; type = $type; value = $val }
    }
    $path = Join-Path $script:State.OutDir '_alias_map.json'
    $rows | Sort-Object alias | ConvertTo-Json | Out-File -FilePath $path -Encoding utf8
    Write-Warning "Đã ghi $path - file này chứa PII gốc, KHÔNG gửi cho LLM."
}
#endregion

#region ---------- Users (dùng chung, có cache) ----------
function Get-AuditUsers {
    [CmdletBinding()]
    param([switch]$Refresh)
    if ($script:State.UserCache -and -not $Refresh) { return , $script:State.UserCache }

    $base = 'id,displayName,userPrincipalName,mail,userType,accountEnabled,createdDateTime,onPremisesSyncEnabled,assignedLicenses'
    # signInActivity cần Entra ID P1 + AuditLog.Read.All, và $top tối đa 500
    $users = Invoke-GraphSafe -Name 'users+signInActivity' -Paged -Uri ('/v1.0/users?$select={0},signInActivity&$top=500' -f $base)
    if ($null -ne $users) {
        $script:State.SignInActivityOk = $true
    }
    else {
        $script:State.SignInActivityOk = $false
        $users = Invoke-GraphSafe -Name 'users' -Paged -Uri ('/v1.0/users?$select={0}&$top=999' -f $base)
    }
    if ($null -eq $users) { $users = @() }
    $script:State.UserCache = $users
    return , $users
}

function Test-AuditSignInActivity { return [bool]$script:State.SignInActivityOk }

function ConvertTo-AuditUserRecord {
    param([Parameter(Mandatory)]$User)
    $last = $null
    if ($User.signInActivity) {
        $last = ConvertTo-AuditUtcDate $User.signInActivity.lastSuccessfulSignInDateTime
        if (-not $last) { $last = ConvertTo-AuditUtcDate $User.signInActivity.lastSignInDateTime }
    }
    $created  = ConvertTo-AuditUtcDate $User.createdDateTime
    $upnAlias = Get-AuditAlias $User.userPrincipalName 'user'
    $display  = if ($script:State.Pseudonymize) { $upnAlias } else { $User.displayName }
    [ordered]@{
        id                      = $User.id
        upn                     = $upnAlias
        display_name            = $display
        user_type               = $User.userType
        account_enabled         = [bool]$User.accountEnabled
        created                 = if ($created) { $created.ToString('o') } else { $null }
        days_since_created      = if ($created) { [int][math]::Floor(([datetime]::UtcNow - $created).TotalDays) } else { $null }
        synced_from_onprem      = [bool]$User.onPremisesSyncEnabled
        license_count           = Get-AuditCount $User.assignedLicenses
        sku_ids                 = @($User.assignedLicenses | ForEach-Object { $_.skuId })
        last_sign_in            = if ($last) { $last.ToString('o') } else { $null }
        days_since_last_sign_in = if ($last) { [int][math]::Floor(([datetime]::UtcNow - $last).TotalDays) } else { $null }
    }
}
#endregion

#region ---------- Ghi snapshot ----------
function Save-AuditSnapshot {
    param(
        [Parameter(Mandatory)][string]$Domain,
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)]$Data,
        [string[]]$Sources = @(),
        $Summary,
        [string[]]$Notes = @()
    )
    $snap = [ordered]@{
        schema_version = '1.0'
        domain         = $Domain
        collector      = $Name
        tenant_id      = $script:State.TenantId
        collected_at   = [datetime]::UtcNow.ToString('o')
        pseudonymized  = $script:State.Pseudonymize
        sources        = $Sources
        notes          = $Notes
        errors         = @($script:State.Errors)
        summary        = $Summary
        data           = $Data
    }
    $path = Join-Path $script:State.OutDir "$Name.json"
    $snap | ConvertTo-Json -Depth 20 | Out-File -FilePath $path -Encoding utf8
    [pscustomobject]@{
        Name       = $Name
        File       = $path
        ErrorCount = $script:State.Errors.Count
        Summary    = $Summary
    }
}
#endregion

Export-ModuleMember -Function Connect-AuditGraph, Test-AuditPermission, Initialize-AuditRun, Start-AuditCollector,
Get-AuditCredentialFilePath, Save-AuditCredentials, Get-AuditSavedCredentials, Get-AuditSecretFromStore,
Invoke-GraphWithRetry, Invoke-GraphPaged, Invoke-GraphSafe, Get-AuditLastTruncated, Select-AuditSingle,
ConvertTo-AuditArray, Get-AuditCount, Get-AuditUniqueCount, ConvertTo-AuditUtcDate, Get-AuditDaysFrom,
Get-AuditAlias, Export-AuditAliasMap,
Get-AuditUsers, Test-AuditSignInActivity, ConvertTo-AuditUserRecord,
Save-AuditSnapshot
