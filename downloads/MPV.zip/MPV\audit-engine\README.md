# Audit Rules Engine (Python, không phụ thuộc thư viện ngoài)

Đọc 5 file snapshot của collector PowerShell -> kiểm tra bằng 41 rule -> ghi kết quả. **Không có LLM** ở bước này.

## Chạy
```bash
python3 --version                       # cần >= 3.10
python3 run_audit.py --snapshots ../m365-audit-collectors/snapshots/<tenant-id>/<run-id> --out out
python3 run_audit.py --snapshots ... --fail-on High     # exit code 2 nếu còn finding fail >= High
python3 -m unittest discover -s tests -v                # chạy test (dùng dữ liệu giả lập)
```

## Đầu ra: `out/<run_id>/`
| File | Nội dung |
|---|---|
| `run.json` | Metadata lần chạy: run_id, tenant, thời gian, phiên bản engine/ruleset, quyền đã consent, hash các file đầu vào, thống kê |
| `snapshot.json` | Snapshot hợp nhất: facts (summary của 5 collector) + endpoint nào thiếu license/quyền + sha256 file gốc |
| `results.json` | Kết quả của MỌI rule: pass / fail / warning / not_applicable / unknown (kể cả pass) |
| `findings.json` | Chỉ fail + warning, theo finding schema, đã sắp xếp theo severity. Đây là thứ đưa cho tầng LLM |

## Ý nghĩa trạng thái
- `pass` đạt; `fail` lệch baseline rõ ràng; `warning` có dấu hiệu rủi ro, cần người xem ngữ cảnh
- `not_applicable` tenant không có license/tính năng (collector ghi `hint=license`); **không phải lỗi, không tính vào findings**
- `unknown` thiếu dữ liệu để kết luận (thiếu quyền, collector lỗi, thiếu file) - cần xử lý để audit đầy đủ

## Thêm một rule mới (xem engine/rules/*.py)
```python
@rule(id="ID-010", domain="Identity", title="...", severity="Medium", risk="...", remediation=["..."], effort="Low",
      frameworks=["..."], sources=["identity"], needs=[("identity", "users")], tags=["hygiene"])
def id_010(snap):
    n = snap.identity.summary.get("some_fact")
    if n is None:  return unknown("Thiếu số liệu")
    return ok({"some_fact": n}) if n == 0 else fail({"some_fact": n}, "mô tả", affected=[...])
```
`needs` = endpoint của collector phải đọc được. Thiếu license -> rule tự thành `not_applicable`, thiếu quyền/lỗi -> `unknown`.
Trả `severity=` trong fail()/warn() để leo thang theo ngữ cảnh (ví dụ ID-001, CA-002).

## Lưu ý
- Trường `framework` đang ghi chủ đề (ví dụ "CIS M365 Foundations - MFA cho vai trò quản trị"). Hãy thay bằng số mục cụ thể
  theo phiên bản benchmark bạn đối chiếu; đừng tin số mục do công cụ/AI tự sinh khi chưa kiểm chứng.
- Ngưỡng (95% MFA, 2-5 Global Admin, 90 ngày bất hoạt...) là mặc định hợp lý, hãy chỉnh theo chính sách của bạn.
- Bộ test dùng dữ liệu giả lập mô phỏng đầu ra collector; cần chạy thử với snapshot thật và rà soát false positive.
