#Requires -Version 7.0
<#
.SYNOPSIS
  Collector 1 - Identity: users, guests, tài khoản bất hoạt, thông tin tenant, security defaults,
  chính sách guest/tạo app, risky users.
.NOTES
  Quyền Graph (Application, read-only): User.Read.All, AuditLog.Read.All, Organization.Read.All,
  Domain.Read.All, Policy.Read.All, IdentityRiskyUser.Read.All
  signInActivity và riskyUsers cần Entra ID P1/P2 - thiếu license sẽ ghi vào mục "errors" (hint=license).
#>
[CmdletBinding()]
param(
    [string]$TenantId,
    [string]$ClientId,
    [string]$OutDir,
    [int]$StaleDays = 90,
    [switch]$Pseudonymize
)
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot 'AuditCommon.psm1') -ErrorAction Stop
Start-AuditCollector -TenantId $TenantId -ClientId $ClientId -OutDir $OutDir -Pseudonymize:$Pseudonymize `
    -Permissions 'User.Read.All', 'AuditLog.Read.All', 'Organization.Read.All', 'Domain.Read.All', 'Policy.Read.All', 'IdentityRiskyUser.Read.All'

Write-Host '[01] Identity collector...' -ForegroundColor Cyan

# ---- Thông tin tenant / policy ----
$org         = Select-AuditSingle (Invoke-GraphSafe -Name 'organization' -Uri '/v1.0/organization')
$domains     = Invoke-GraphSafe -Name 'domains' -Paged -Uri '/v1.0/domains'
$secDefaults = Invoke-GraphSafe -Name 'securityDefaults' -Uri '/v1.0/policies/identitySecurityDefaultsEnforcementPolicy'
$authz       = Select-AuditSingle (Invoke-GraphSafe -Name 'authorizationPolicy' -Uri '/v1.0/policies/authorizationPolicy')
$riskyUri    = '/v1.0/identityProtection/riskyUsers?$filter=' + [uri]::EscapeDataString("riskState eq 'atRisk'") + '&$top=500'
$risky       = Invoke-GraphSafe -Name 'riskyUsers' -Paged -Uri $riskyUri

# ---- Users ----
$rawUsers = Get-AuditUsers
$users    = @($rawUsers | ForEach-Object { ConvertTo-AuditUserRecord $_ })
$signInOk = Test-AuditSignInActivity

$members = @($users | Where-Object { $_.user_type -eq 'Member' })
$guests  = @($users | Where-Object { $_.user_type -eq 'Guest' })

function Test-Stale($u, [int]$days) {
    # Bất hoạt = đang bật và (đăng nhập cuối > N ngày, hoặc chưa từng đăng nhập mà tài khoản đã tạo > N ngày)
    if (-not $u.account_enabled) { return $false }
    if ($null -ne $u.days_since_last_sign_in) { return ($u.days_since_last_sign_in -gt $days) }
    return ($null -ne $u.days_since_created -and $u.days_since_created -gt $days)
}

$staleMembers = @(); $staleGuests = @()
if ($signInOk) {
    $staleMembers = @($members | Where-Object { Test-Stale $_ $StaleDays })
    $staleGuests  = @($guests  | Where-Object { Test-Stale $_ $StaleDays })
}

$riskyRecords = @()
if ($null -ne $risky) {
    $riskyRecords = @($risky | ForEach-Object {
            [ordered]@{
                id         = $_.id
                upn        = Get-AuditAlias $_.userPrincipalName 'user'
                risk_level = $_.riskLevel
                risk_state = $_.riskState
                risk_last_updated = $_.riskLastUpdatedDateTime
            }
        })
}

# ---- Tổng hợp (facts, KHÔNG phải findings - rules engine sẽ đánh giá sau) ----
$summary = [ordered]@{
    total_users                  = $users.Count
    members                      = $members.Count
    guests                       = $guests.Count
    enabled_users                = @($users | Where-Object { $_.account_enabled }).Count
    disabled_users               = @($users | Where-Object { -not $_.account_enabled }).Count
    synced_from_onprem           = @($users | Where-Object { $_.synced_from_onprem }).Count
    cloud_only_members           = @($members | Where-Object { -not $_.synced_from_onprem }).Count
    sign_in_activity_available   = $signInOk
    stale_days_threshold         = $StaleDays
    stale_enabled_members        = $staleMembers.Count
    stale_enabled_guests         = $staleGuests.Count
    disabled_with_licenses       = @($users | Where-Object { -not $_.account_enabled -and $_.license_count -gt 0 }).Count
    risky_users_at_risk          = if ($null -ne $risky) { $riskyRecords.Count } else { $null }
    security_defaults_enabled    = $secDefaults.isEnabled
    guest_invite_policy          = $authz.allowInvitesFrom
    guest_user_role_id           = $authz.guestUserRoleId
    users_can_create_apps        = $authz.defaultUserRolePermissions.allowedToCreateApps
    users_can_create_tenants     = $authz.defaultUserRolePermissions.allowedToCreateTenants
    users_can_create_security_groups = $authz.defaultUserRolePermissions.allowedToCreateSecurityGroups
    block_msol_powershell        = $authz.blockMsolPowerShell
    onprem_sync_enabled          = $org.onPremisesSyncEnabled
    onprem_last_sync             = $org.onPremisesLastSyncDateTime
}

$data = [ordered]@{
    organization = if ($org) {
        [ordered]@{
            id                 = $org.id
            display_name       = $org.displayName
            created            = $org.createdDateTime
            onprem_sync        = $org.onPremisesSyncEnabled
            onprem_last_sync   = $org.onPremisesLastSyncDateTime
        }
    } else { $null }
    domains = if ($null -ne $domains) {
        @($domains | ForEach-Object {
                [ordered]@{
                    id                              = $_.id
                    is_verified                     = $_.isVerified
                    is_default                      = $_.isDefault
                    authentication_type             = $_.authenticationType
                    password_validity_period_days   = $_.passwordValidityPeriodInDays
                    password_notification_window_days = $_.passwordNotificationWindowInDays
                }
            })
    } else { $null }
    security_defaults    = $secDefaults
    authorization_policy = if ($authz) {
        [ordered]@{
            allow_invites_from                          = $authz.allowInvitesFrom
            guest_user_role_id                          = $authz.guestUserRoleId
            allowed_to_use_sspr                         = $authz.allowedToUseSSPR
            allow_email_verified_users_to_join          = $authz.allowEmailVerifiedUsersToJoinOrganization
            block_msol_powershell                       = $authz.blockMsolPowerShell
            default_user_role_permissions               = $authz.defaultUserRolePermissions
        }
    } else { $null }
    risky_users = $riskyRecords
    users       = $users
}

$notes = @(
    'days_since_last_sign_in dùng lastSuccessfulSignInDateTime (nếu có) rồi tới lastSignInDateTime; cần Entra P1.',
    'Tài khoản chưa từng đăng nhập: chỉ tính là bất hoạt khi đã tạo quá StaleDays ngày.',
    'Tài khoản dịch vụ/shared mailbox có thể bị tính là bất hoạt - cần người rà soát.'
)
$result = Save-AuditSnapshot -Domain 'Identity' -Name '01_identity' -Data $data -Summary $summary -Notes $notes `
    -Sources @('/v1.0/organization', '/v1.0/domains', '/v1.0/users', '/v1.0/policies/authorizationPolicy',
    '/v1.0/policies/identitySecurityDefaultsEnforcementPolicy', '/v1.0/identityProtection/riskyUsers')
Write-Host ("    -> {0} users, {1} guests, {2} lỗi/cảnh báo" -f $summary.total_users, $summary.guests, $result.ErrorCount)
$result
