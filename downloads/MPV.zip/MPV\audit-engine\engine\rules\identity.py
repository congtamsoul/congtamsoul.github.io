from datetime import datetime

from ..model import dig, fail, na, ok, unknown, warn
from ..registry import rule


def _is_stale(u: dict, days: int) -> bool:
    if not u.get("account_enabled"):
        return False
    last = u.get("days_since_last_sign_in")
    if last is not None:
        return last > days
    created = u.get("days_since_created")
    return created is not None and created > days


def _parse(ts):
    try:
        return datetime.fromisoformat(str(ts).replace("Z", "+00:00"))
    except Exception:  # noqa: BLE001
        return None


@rule(id="ID-001", domain="Identity", title="Tài khoản đặc quyền chưa đăng ký MFA", severity="High",
      risk="Tài khoản admin bị chiếm bằng mật khẩu bị lộ sẽ cho kẻ tấn công quyền kiểm soát tenant.",
      remediation=["Bật Conditional Access bắt buộc MFA cho directory roles",
                   "Yêu cầu admin đăng ký phương thức mạnh (Authenticator/FIDO2)",
                   "Chạy lại audit sau 7 ngày để xác nhận"],
      effort="Low", frameworks=["CIS M365 Foundations - MFA cho vai trò quản trị", "Microsoft Entra security baseline"],
      sources=["baseline", "ca", "identity"],
      needs=[("baseline", "userRegistrationDetails"), ("baseline", "roleAssignments")], tags=["mfa", "privileged"])
def id_001(snap):
    roles = dig(snap.baseline.data, "admin_roles", "summary") or {}
    n, total = roles.get("privileged_users_without_mfa"), roles.get("privileged_active_users")
    if n is None:
        return unknown("Thiếu số liệu admin_roles trong snapshot 03")
    ev = {"privileged_active_users": total, "privileged_users_without_mfa": n}
    if n == 0:
        return ok(ev)
    affected = sorted({a["upn"] for a in dig(snap.baseline.data, "admin_roles", "active") or []
                       if a.get("principal_type") == "user" and a.get("is_privileged") and a.get("mfa_registered") is False})
    sev = "High"
    if snap.ca.summary.get("mfa_covers_admin_roles") is False and snap.identity.summary.get("security_defaults_enabled") is not True:
        sev = "Critical"   # chưa đăng ký MFA VÀ không có policy bắt buộc MFA cho admin
        ev["ca_enforces_admin_mfa"] = False
    return fail(ev, f"{n}/{total} tài khoản đặc quyền chưa đăng ký MFA", severity=sev, affected=affected)


@rule(id="ID-002", domain="Identity", title="Tỷ lệ đăng ký MFA của người dùng dưới baseline", severity="Medium",
      risk="Người dùng chưa có MFA dễ bị chiếm tài khoản qua phishing/password spray.",
      remediation=["Triển khai registration campaign / Conditional Access yêu cầu đăng ký MFA",
                   "Ưu tiên nhóm có quyền truy cập dữ liệu nhạy cảm", "Theo dõi tỷ lệ hàng tuần"],
      effort="Medium", frameworks=["CIS M365 Foundations - MFA cho tất cả người dùng"],
      sources=["baseline"], needs=[("baseline", "userRegistrationDetails")], tags=["mfa"])
def id_002(snap):
    m = snap.baseline.summary.get("mfa") or {}
    pct = m.get("mfa_registered_pct")
    if pct is None:
        return unknown("Không có số liệu đăng ký MFA")
    ev = {"users_total": m.get("users_total"), "mfa_registered": m.get("mfa_registered"), "mfa_registered_pct": pct}
    if pct >= 95:
        return ok(ev)
    if pct >= 90:
        return warn(ev, f"MFA đạt {pct}% (mục tiêu >= 95%)", severity="Low")
    return fail(ev, f"MFA đạt {pct}% (mục tiêu >= 95%; số liệu gồm cả guest/tài khoản bị khóa)",
                severity="High" if pct < 50 else "Medium")


@rule(id="ID-003", domain="Identity", title="Người dùng chỉ có phương thức MFA yếu (SMS/thoại/email)", severity="Low",
      risk="SMS/thoại dễ bị SIM-swap và chặn bắt; email không phải yếu tố mạnh.",
      remediation=["Khuyến khích Microsoft Authenticator hoặc FIDO2", "Dùng Authentication Strengths trong CA cho nhóm rủi ro cao"],
      effort="Medium", frameworks=["Microsoft Entra - authentication strengths"], sources=["baseline"],
      needs=[("baseline", "userRegistrationDetails")], tags=["mfa", "auth-methods"])
def id_003(snap):
    m = snap.baseline.summary.get("mfa") or {}
    n = m.get("users_only_weak_methods")
    if n is None:
        return unknown("Không có số liệu")
    ev = {"users_only_weak_methods": n, "mfa_registered": m.get("mfa_registered")}
    return ok(ev) if n == 0 else warn(ev, f"{n} người dùng chỉ có SMS/thoại/email")


def _stale_rule(kind):
    label, utype, key = (("thành viên", "Member", "stale_enabled_members") if kind == "members"
                         else ("guest", "Guest", "stale_enabled_guests"))

    def fn(snap):
        s = snap.identity.summary
        if not s.get("sign_in_activity_available"):
            return na("Không có signInActivity (cần Entra ID P1) nên không đánh giá được tài khoản bất hoạt")
        days, n = s.get("stale_days_threshold", 90), s.get(key)
        if n is None:
            return unknown("Thiếu số liệu")
        ev = {key: n, "stale_days_threshold": days}
        if n == 0:
            return ok(ev)
        affected = [u["upn"] for u in snap.identity.data.get("users", [])
                    if u.get("user_type") == utype and _is_stale(u, days)]
        return warn(ev, f"{n} {label} đang bật nhưng không đăng nhập > {days} ngày", affected=affected)
    return fn


rule(id="ID-004", domain="Identity", title="Tài khoản thành viên bất hoạt vẫn đang bật", severity="Medium",
     risk="Tài khoản bỏ quên là mục tiêu lý tưởng cho kẻ tấn công vì không ai để ý bất thường.",
     remediation=["Rà soát với HR/quản lý", "Vô hiệu hóa rồi xóa theo quy trình", "Tự động hóa bằng access review/lifecycle"],
     effort="Low", frameworks=["Quản lý vòng đời tài khoản"], sources=["identity"],
     needs=[("identity", "users")], tags=["hygiene"])(_stale_rule("members"))

rule(id="ID-005", domain="Identity", title="Tài khoản guest bất hoạt vẫn đang bật", severity="Low",
     risk="Guest cũ giữ quyền truy cập dữ liệu/Teams của tổ chức sau khi hết nhu cầu hợp tác.",
     remediation=["Thiết lập Access Review cho guest", "Xóa guest không còn dự án"],
     effort="Low", frameworks=["Quản lý truy cập bên ngoài"], sources=["identity"],
     needs=[("identity", "users")], tags=["guests", "hygiene"])(_stale_rule("guests"))


@rule(id="ID-006", domain="Identity", title="Có người dùng đang ở trạng thái 'at risk'", severity="High",
      risk="Identity Protection phát hiện dấu hiệu lộ thông tin đăng nhập hoặc đăng nhập bất thường.",
      remediation=["Điều tra từng user trong Identity Protection", "Buộc đổi mật khẩu/thu hồi session",
                   "Bật CA theo user risk để tự khắc phục"],
      effort="Medium", frameworks=["Microsoft Entra ID Protection"], sources=["identity"],
      needs=[("identity", "riskyUsers")], tags=["identity-protection"])
def id_006(snap):
    n = snap.identity.summary.get("risky_users_at_risk")
    if n is None:
        return unknown("Không có số liệu risky users")
    ev = {"risky_users_at_risk": n}
    if n == 0:
        return ok(ev)
    affected = [u["upn"] for u in snap.identity.data.get("risky_users", [])]
    high = sum(1 for u in snap.identity.data.get("risky_users", []) if u.get("risk_level") == "high")
    ev["high_risk"] = high
    return fail(ev, f"{n} user đang at-risk ({high} mức high)", severity="Critical" if high else "High", affected=affected)


@rule(id="ID-007", domain="Identity", title="Chính sách mời guest quá rộng", severity="Medium",
      risk="Cho phép mọi người dùng (kể cả guest) mời người ngoài làm mất kiểm soát truy cập bên ngoài.",
      remediation=["Giới hạn quyền mời guest cho admin và Guest Inviter",
                   "Bật cấu hình collaboration restrictions/allow-list domain"],
      effort="Low", frameworks=["CIS M365 Foundations - external collaboration"], sources=["identity"],
      needs=[("identity", "authorizationPolicy")], tags=["guests"])
def id_007(snap):
    v = snap.identity.summary.get("guest_invite_policy")
    if v is None:
        return unknown("Không đọc được allowInvitesFrom")
    ev = {"allowInvitesFrom": v}
    if v == "everyone":
        return fail(ev, "Mọi người (kể cả guest) có thể mời guest")
    if v == "adminsGuestInvitersAndAllMembers":
        return warn(ev, "Mọi thành viên có thể mời guest", severity="Low")
    return ok(ev)


@rule(id="ID-008", domain="Identity", title="Người dùng thường được tạo app/tenant", severity="Low",
      risk="Người dùng tự đăng ký app làm tăng số app không được quản lý và bề mặt consent.",
      remediation=["Tắt 'Users can register applications'", "Dùng vai trò Application Developer cho người cần"],
      effort="Low", frameworks=["Microsoft Entra - default user role permissions"], sources=["identity"],
      needs=[("identity", "authorizationPolicy")], tags=["apps", "governance"])
def id_008(snap):
    s = snap.identity.summary
    ev = {"users_can_create_apps": s.get("users_can_create_apps"), "users_can_create_tenants": s.get("users_can_create_tenants")}
    if ev["users_can_create_apps"] is None:
        return unknown("Không đọc được defaultUserRolePermissions")
    return warn(ev, "Người dùng thường có quyền tạo app/tenant") if (ev["users_can_create_apps"] or ev["users_can_create_tenants"]) else ok(ev)


@rule(id="ID-009", domain="Identity", title="Đồng bộ Entra Connect/Cloud Sync bị chậm hoặc dừng", severity="Medium",
      risk="Thay đổi (khóa tài khoản, đổi mật khẩu) trên AD không phản ánh lên cloud kịp thời.",
      remediation=["Kiểm tra dịch vụ Entra Connect Sync và lỗi export", "Xem Connect Health nếu có"],
      effort="Medium", frameworks=["Vận hành hybrid identity"], sources=["identity"],
      needs=[("identity", "organization")], tags=["hybrid", "availability"])
def id_009(snap):
    s = snap.identity.summary
    if not s.get("onprem_sync_enabled"):
        return na("Tenant không bật đồng bộ từ on-premises")
    last, now = _parse(s.get("onprem_last_sync")), _parse(snap.identity.collected_at)
    if not last or not now:
        return unknown("Không xác định được thời điểm sync gần nhất")
    hours = round((now - last).total_seconds() / 3600, 1)
    ev = {"onprem_last_sync": s.get("onprem_last_sync"), "hours_since_last_sync": hours}
    return ok(ev) if hours <= 24 else fail(ev, f"Lần sync gần nhất cách {hours} giờ", severity="High" if hours > 72 else "Medium")
