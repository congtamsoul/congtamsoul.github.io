"""Kiểu dữ liệu dùng chung: trạng thái, kết quả của một rule, hàm tiện ích."""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any

SEVERITIES = ["Info", "Low", "Medium", "High", "Critical"]
SEV_RANK = {s: i for i, s in enumerate(SEVERITIES)}


class Status(str, Enum):
    PASS = "pass"                      # đạt baseline
    FAIL = "fail"                      # lệch baseline rõ ràng
    WARNING = "warning"                # có dấu hiệu rủi ro, cần người xem ngữ cảnh
    NOT_APPLICABLE = "not_applicable"  # tenant không có license/tính năng tương ứng
    UNKNOWN = "unknown"                # không đủ dữ liệu để kết luận (thiếu quyền, collector lỗi...)


@dataclass
class Outcome:
    status: Status
    evidence: dict[str, Any] = field(default_factory=dict)
    detail: str = ""
    severity: str | None = None        # ghi đè severity mặc định của rule (leo thang theo ngữ cảnh)
    affected: list[str] = field(default_factory=list)


def ok(evidence=None, detail=""):
    return Outcome(Status.PASS, evidence or {}, detail)


def fail(evidence=None, detail="", severity=None, affected=None):
    return Outcome(Status.FAIL, evidence or {}, detail, severity, list(affected or []))


def warn(evidence=None, detail="", severity=None, affected=None):
    return Outcome(Status.WARNING, evidence or {}, detail, severity, list(affected or []))


def na(reason):
    return Outcome(Status.NOT_APPLICABLE, detail=reason)


def unknown(reason):
    return Outcome(Status.UNKNOWN, detail=reason)


def dig(obj, *path):
    """Lấy giá trị lồng nhau an toàn: dig(d, 'a', 'b') -> d['a']['b'] hoặc None."""
    cur = obj
    for key in path:
        if not isinstance(cur, dict) or key not in cur:
            return None
        cur = cur[key]
    return cur
