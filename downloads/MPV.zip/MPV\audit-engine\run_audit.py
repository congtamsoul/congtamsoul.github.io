#!/usr/bin/env python3
"""Rules engine: đọc thư mục snapshot của collector -> run.json, snapshot.json, results.json, findings.json.

Ví dụ:
  python run_audit.py --snapshots ../snapshots/<tenant-id>/<run> --out out
  python run_audit.py --snapshots ... --fail-on High     # exit code 2 nếu còn finding fail >= High (dùng cho CI)
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

from engine import ENGINE_VERSION, RULESET_VERSION
from engine.model import SEV_RANK, SEVERITIES
from engine.registry import RULES
from engine.runner import build_findings, evaluate, summarize
from engine.snapshot import Snapshot
import engine.rules  # noqa: F401  (đăng ký rule)


def now():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def write(path: Path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--snapshots", required=True, help="Thư mục chứa 01_identity.json ... 05_licenses.json")
    ap.add_argument("--out", default="out", help="Thư mục gốc ghi kết quả")
    ap.add_argument("--tenant-name", help="Ghi đè tên tenant trong báo cáo")
    ap.add_argument("--fail-on", choices=SEVERITIES, help="Exit 2 nếu có finding status=fail với severity >= mức này")
    args = ap.parse_args(argv)

    started = now()
    snap = Snapshot(args.snapshots, tenant_name=args.tenant_name)
    for p in snap.problems:
        print(f"[!] {p}", file=sys.stderr)
    if snap.fatal_problems:
        print("Dừng: snapshot không nhất quán.", file=sys.stderr)
        return 1

    manifest = snap.manifest or {}
    run_id = manifest.get("run_id") or Path(args.snapshots).name
    results = evaluate(snap, RULES)
    findings = build_findings(results, snap, run_id)
    stats = summarize(results)

    gaps = stats["by_status"].get("unknown", 0) > 0 or bool(snap.problems)
    run = {
        "run_id": run_id,
        "tenant_id": snap.tenant_id,
        "tenant_name": snap.tenant_name,
        "started_at": started,
        "finished_at": now(),
        "status": "completed_with_gaps" if gaps else "completed",
        "engine_version": ENGINE_VERSION,
        "ruleset_version": RULESET_VERSION,
        "rules_total": len(RULES),
        "pseudonymized": snap.pseudonymized,
        "collector": {   # lấy từ _manifest.json của Run-Collectors.ps1 (nếu có)
            "started_at": manifest.get("started_at"), "finished_at": manifest.get("finished_at"),
            "graph_sdk_version": manifest.get("graph_sdk_version"), "powershell_version": manifest.get("powershell_version"),
            "consent_scopes": manifest.get("consent_scopes"),
            "collectors": manifest.get("collectors"),
        },
        "inputs": {s.filename: {"sha256": s.sha256, "collected_at": s.collected_at} for s in snap.sources.values() if s.present},
        "problems": snap.problems,
        "stats": stats,
    }

    out = Path(args.out) / run_id
    out.mkdir(parents=True, exist_ok=True)
    clean = [{k: v for k, v in r.items() if k != "_rule"} for r in results]
    write(out / "run.json", run)
    write(out / "snapshot.json", snap.to_dict(run_id))
    write(out / "results.json", clean)
    write(out / "findings.json", {"run_id": run_id, "tenant_id": snap.tenant_id, "findings": findings})

    # ---- Hiển thị ----
    print(f"\n== {snap.tenant_name} | run {run_id} | {run['status']} ==")
    print(f"Rules: {stats['rules_total']} | " + ", ".join(f"{k}={v}" for k, v in sorted(stats["by_status"].items())))
    print(f"Coverage (đã đánh giá được): {stats['coverage_pct']}%")
    print("Findings mở:", ", ".join(f"{k}={v}" for k, v in stats["open_by_severity"].items() if v) or "không có")
    for f in findings:
        print(f"  [{f['severity']:<8}] {f['status']:<7} {f['id']:<8} {f['title']}")
    gaps_list = [r for r in clean if r["status"] == "unknown"]
    if gaps_list:
        print("\nCần xử lý để có kết luận (unknown):")
        for r in gaps_list:
            print(f"  {r['rule_id']:<8} {r['detail']}")
    print(f"\nĐã ghi: {out}")

    if args.fail_on:
        limit = SEV_RANK[args.fail_on]
        if any(f["status"] == "fail" and SEV_RANK[f["severity"]] >= limit for f in findings):
            return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
