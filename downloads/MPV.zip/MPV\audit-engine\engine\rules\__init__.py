"""Import các module để decorator @rule đăng ký rule vào registry."""
from . import identity, conditional_access, baseline, apps, licenses  # noqa: F401
