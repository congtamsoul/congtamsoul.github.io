"""Chạy rule trên snapshot -> results (mọi kết quả) -> findings (chỉ fail/warning)."""
from __future__ import annotations

from collections import Counter

from .model import SEV_RANK, Outcome, Status, unknown
from .registry import Rule

AFFECTED_CAP = 25

# trạng thái endpoint của collector -> trạng thái rule + lời giải thích
NEED_MAP = {
    "license": (Status.NOT_APPLICABLE, "Tenant không có license/tính năng cần thiết ({src}:{ep}); bỏ qua rule."),
    "permission": (Status.UNKNOWN, "Thiếu quyền Graph khi đọc {src}:{ep}; cấp quyền rồi chạy lại collector."),
    "not_found": (Status.UNKNOWN, "Không tìm thấy tài nguyên {src}:{ep} (404)."),
    "error": (Status.UNKNOWN, "Collector lỗi khi đọc {src}:{ep}; xem mục errors của file snapshot."),
    "missing": (Status.UNKNOWN, "Thiếu file snapshot '{src}' hoặc file không đọc được."),
}


def run_rule(snap, r: Rule) -> dict:
    outcome: Outcome | None = None
    for need in r.needs:
        st = snap.sources[need.source].state(need.endpoint)
        if st != "ok":
            status, msg = NEED_MAP[st]
            outcome = Outcome(status, detail=msg.format(src=need.source, ep=need.endpoint))
            break
    if outcome is None:
        try:
            outcome = r.fn(snap)
            if not isinstance(outcome, Outcome):
                raise TypeError("rule phải trả về Outcome (ok/fail/warn/na/unknown)")
        except Exception as exc:  # noqa: BLE001 - một rule lỗi không được làm hỏng cả lần audit
            outcome = unknown(f"Lỗi khi chạy rule: {type(exc).__name__}: {exc}")

    return {
        "rule_id": r.id,
        "domain": r.domain,
        "title": r.title,
        "status": outcome.status.value,
        "severity": outcome.severity or r.severity,
        "detail": outcome.detail,
        "evidence": outcome.evidence,
        "affected": outcome.affected[:AFFECTED_CAP],
        "affected_total": len(outcome.affected),
        "tags": r.tags,
        "_rule": r,
    }


def evaluate(snap, rules: list[Rule]) -> list[dict]:
    return [run_rule(snap, r) for r in rules]


def to_finding(res: dict, snap, run_id: str) -> dict:
    r: Rule = res["_rule"]
    return {
        "id": res["rule_id"],
        "run_id": run_id,
        "domain": res["domain"],
        "title": res["title"],
        "status": res["status"],                     # fail | warning (warning = cần người xem ngữ cảnh)
        "severity": res["severity"],
        "detail": res["detail"],
        "evidence": {
            "values": res["evidence"],
            "sources": [{"file": snap.sources[k].filename, "sha256": snap.sources[k].sha256,
                         "collected_at": snap.sources[k].collected_at} for k in r.sources if snap.sources[k].present],
        },
        "affected": res["affected"],
        "affected_total": res["affected_total"],
        "risk": r.risk,
        "remediation": r.remediation,
        "effort": r.effort,
        "framework": r.frameworks,
        "tags": r.tags,
    }


def build_findings(results, snap, run_id) -> list[dict]:
    items = [to_finding(x, snap, run_id) for x in results if x["status"] in ("fail", "warning")]
    items.sort(key=lambda f: (-SEV_RANK[f["severity"]], 0 if f["status"] == "fail" else 1, f["id"]))
    return items


def summarize(results) -> dict:
    by_status = Counter(r["status"] for r in results)
    evaluated = by_status["pass"] + by_status["fail"] + by_status["warning"]
    sev = Counter(r["severity"] for r in results if r["status"] in ("fail", "warning"))
    return {
        "rules_total": len(results),
        "by_status": dict(by_status),
        "coverage_pct": round(100.0 * evaluated / len(results), 1) if results else None,
        "open_by_severity": {s: sev.get(s, 0) for s in ("Critical", "High", "Medium", "Low", "Info")},
    }
