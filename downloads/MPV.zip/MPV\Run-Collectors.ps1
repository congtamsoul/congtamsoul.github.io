#Requires -Version 7.0
<#
.SYNOPSIS
  Chạy các collector theo thứ tự, kết nối Graph một lần (client secret), ghi manifest.
.EXAMPLE
  # Secret nhập an toàn, không lưu vào history:
  $env:M365_CLIENT_SECRET = Read-Host 'Client secret' -MaskInput
  ./Run-Collectors.ps1 -TenantId <tenant-guid> -ClientId <app-guid> -Pseudonymize
.EXAMPLE
  ./Run-Collectors.ps1 -TenantId <guid> -ClientId <guid> -Only Identity,ConditionalAccess
#>
[CmdletBinding()]
param(
    [string]$TenantId,
    [string]$ClientId,
    [string]$OutRoot = (Join-Path $PSScriptRoot 'snapshots'),
    [ValidateSet('Identity', 'ConditionalAccess', 'SecurityBaseline', 'Apps', 'Licenses')]
    [string[]]$Only,
    [int]$StaleDays = 90,
    [switch]$Pseudonymize,
    [switch]$SkipSignInLogs,
    [switch]$IncludeNonInteractive
)
$ErrorActionPreference = 'Stop'

# -Force chỉ ở đây (reset state); các collector import không -Force nên dùng chung state/cache
Import-Module (Join-Path $PSScriptRoot 'AuditCommon.psm1') -Force -ErrorAction Stop

$saved = Get-AuditSavedCredentials
if (-not $TenantId -and $saved) { $TenantId = $saved.TenantId }
if (-not $ClientId -and $saved) { $ClientId = $saved.ClientId }
if (-not $TenantId -or -not $ClientId) {
    throw 'Thiếu TenantId hoặc ClientId. Hãy truyền tham số, hoặc chạy Setup-AuditCredentials.ps1 để lưu credential một lần.'
}

$runId  = Get-Date -Format 'yyyyMMdd-HHmmss'
$outDir = Join-Path $OutRoot "$TenantId/$runId"
New-Item -ItemType Directory -Path $outDir -Force | Out-Null

Write-Host "== M365 audit collectors | tenant $TenantId | run $runId ==" -ForegroundColor Green
$ctx = Connect-AuditGraph -TenantId $TenantId -ClientId $ClientId
Write-Host "Đã kết nối (AuthType: $($ctx.AuthType))." -ForegroundColor Green

# Thứ tự quan trọng: Identity nạp cache users cho các collector sau
$plan = [ordered]@{
    Identity          = '01-Identity.ps1'
    ConditionalAccess = '02-ConditionalAccess.ps1'
    SecurityBaseline  = '03-SecurityBaseline.ps1'
    Apps              = '04-Apps.ps1'
    Licenses          = '05-Licenses.ps1'
}
$selected = if ($Only) { $plan.Keys | Where-Object { $_ -in $Only } } else { $plan.Keys }

$manifest = [ordered]@{
    run_id       = $runId
    tenant_id    = $TenantId
    started_at   = [datetime]::UtcNow.ToString('o')
    pseudonymized = [bool]$Pseudonymize
    collectors   = @()
}

foreach ($name in $selected) {
    $script = Join-Path $PSScriptRoot $plan[$name]
    $collectorArgs = @{ TenantId = $TenantId; ClientId = $ClientId; OutDir = $outDir; Pseudonymize = [bool]$Pseudonymize }
    switch ($name) {
        'Identity'         { $collectorArgs.StaleDays = $StaleDays }
        'Licenses'         { $collectorArgs.StaleDays = $StaleDays }
        'SecurityBaseline' { $collectorArgs.SkipSignInLogs = [bool]$SkipSignInLogs; $collectorArgs.IncludeNonInteractive = [bool]$IncludeNonInteractive }
    }
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    $entry = [ordered]@{ collector = $name; status = 'ok'; file = $null; graph_errors = 0; seconds = 0; exception = $null }
    try {
        $res = & $script @collectorArgs | Select-Object -Last 1
        $entry.file         = Split-Path $res.File -Leaf
        $entry.graph_errors = $res.ErrorCount
        if ($res.ErrorCount -gt 0) { $entry.status = 'partial' }
    }
    catch {
        $entry.status    = 'failed'
        $entry.exception = $_.Exception.Message
        Write-Warning "Collector $name lỗi: $($_.Exception.Message)"
    }
    $sw.Stop()
    $entry.seconds = [math]::Round($sw.Elapsed.TotalSeconds, 1)
    $manifest.collectors += $entry
}

Export-AuditAliasMap
$manifest.finished_at = [datetime]::UtcNow.ToString('o')
$manifest | ConvertTo-Json -Depth 6 | Out-File (Join-Path $outDir '_manifest.json') -Encoding utf8
Disconnect-MgGraph | Out-Null

Write-Host "`n== Kết quả ==" -ForegroundColor Green
$manifest.collectors | ForEach-Object { [pscustomobject]$_ } | Format-Table collector, status, graph_errors, seconds, file -AutoSize
Write-Host "Snapshot: $outDir" -ForegroundColor Green
Write-Host 'status=partial nghĩa là một số endpoint lỗi (thường do thiếu license P1/P2 hoặc thiếu quyền) - xem mục "errors" trong từng file JSON.'
