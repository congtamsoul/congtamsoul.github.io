#Requires -Version 7.0
[CmdletBinding()]
param()

Import-Module (Join-Path $PSScriptRoot 'AuditCommon.psm1') -Force -ErrorAction Stop

$tenantId = Read-Host 'Tenant ID'
$clientId = Read-Host 'Client ID'
$clientSecret = Read-Host 'Client secret (sẽ được mã hóa và lưu local)' -AsSecureString

Save-AuditCredentials -TenantId $tenantId -ClientId $clientId -ClientSecret $clientSecret | Out-Null

Write-Host "" 
Write-Host 'Đã lưu credential mã hóa thành công.' -ForegroundColor Green
Write-Host "File: $((Get-AuditCredentialFilePath))" -ForegroundColor Green
Write-Host 'Bây giờ bạn có thể chạy mọi file trong thư mục /MPV mà không cần nhập lại.' -ForegroundColor Green
