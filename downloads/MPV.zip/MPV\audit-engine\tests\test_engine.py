import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import make_fixtures as fx  # noqa: E402
import engine.rules  # noqa: E402,F401
from engine.registry import RULES  # noqa: E402
from engine.runner import build_findings, evaluate, summarize  # noqa: E402
from engine.snapshot import Snapshot  # noqa: E402
import run_audit  # noqa: E402


def run(files):
    with tempfile.TemporaryDirectory() as d:
        fx.write(d, files)
        snap = Snapshot(d)
        res = {r["rule_id"]: r for r in evaluate(snap, RULES)}
        return snap, res


class WeakTenant(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.snap, cls.res = run(fx.weak_tenant())

    def st(self, rid): return self.res[rid]["status"]
    def sev(self, rid): return self.res[rid]["severity"]

    def test_privileged_without_mfa_escalates_to_critical(self):
        self.assertEqual(self.st("ID-001"), "fail")
        self.assertEqual(self.sev("ID-001"), "Critical")          # CA cũng không bắt buộc MFA cho admin
        self.assertEqual(self.res["ID-001"]["affected_total"], 2)

    def test_legacy_auth_escalation(self):
        self.assertEqual(self.st("CA-002"), "fail")
        self.assertEqual(self.sev("CA-002"), "Critical")          # legacy chưa chặn VÀ MFA chưa bắt buộc
        self.assertEqual(self.st("BL-006"), "fail")

    def test_misc_expected_statuses(self):
        expect = {"ID-002": "fail", "ID-004": "warning", "ID-006": "fail", "ID-007": "fail", "ID-009": "fail",
                  "CA-001": "fail", "CA-004": "warning", "CA-005": "warning", "BL-001": "fail", "BL-002": "fail",
                  "BL-003": "fail", "BL-008": "warning", "APP-001": "fail", "APP-005": "fail", "APP-007": "fail",
                  "APP-008": "unknown", "LIC-001": "fail", "LIC-004": "warning"}
        for rid, status in expect.items():
            self.assertEqual(self.st(rid), status, rid)

    def test_risky_high_is_critical(self):
        self.assertEqual(self.sev("ID-006"), "Critical")

    def test_findings_sorted_and_have_required_fields(self):
        findings = build_findings(list(self.res.values()), self.snap, "t")
        required = {"id", "domain", "title", "severity", "evidence", "risk", "remediation", "effort", "framework"}
        for f in findings:
            self.assertTrue(required <= f.keys(), f["id"])
        ranks = [fx_["severity"] for fx_ in findings]
        self.assertEqual(ranks[0], "Critical")


class FreeTenant(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.snap, cls.res = run(fx.free_tenant())

    def test_license_gaps_are_not_applicable_not_failures(self):
        for rid in ("ID-002", "ID-004", "ID-006", "BL-002", "BL-006", "CA-004", "CA-006", "LIC-002"):
            self.assertEqual(self.res[rid]["status"], "not_applicable", rid)

    def test_no_ca_and_no_security_defaults_is_a_failure(self):
        self.assertEqual(self.res["CA-001"]["status"], "fail")    # không có cơ chế bắt buộc MFA nào
        self.assertEqual(self.res["CA-002"]["status"], "fail")

    def test_security_defaults_on_passes_mfa_and_legacy(self):
        files = fx.free_tenant()
        files["01_identity"]["summary"]["security_defaults_enabled"] = True
        _, res = run(files)
        for rid in ("CA-001", "CA-002", "CA-003"):
            self.assertEqual(res[rid]["status"], "pass", rid)


class Robustness(unittest.TestCase):
    def test_missing_file_gives_unknown_not_crash(self):
        files = fx.weak_tenant()
        del files["02_conditional_access"]
        _, res = run(files)
        self.assertEqual(res["CA-004"]["status"], "unknown")

    def test_permission_error_gives_unknown(self):
        files = fx.weak_tenant()
        files["03_security_baseline"]["errors"] = [fx.err("userRegistrationDetails", "permission")]
        _, res = run(files)
        self.assertEqual(res["ID-002"]["status"], "unknown")

    def test_rule_exception_is_contained(self):
        files = fx.weak_tenant()
        files["02_conditional_access"]["data"]["facts"] = [{"state": "enabled", "has_exclusions": True}]  # thiếu 'name'
        _, res = run(files)
        self.assertEqual(res["CA-005"]["status"], "unknown")
        self.assertIn("KeyError", res["CA-005"]["detail"])

    def test_mixed_tenants_is_fatal(self):
        files = fx.weak_tenant()
        files["05_licenses"]["tenant_id"] = "other"
        with tempfile.TemporaryDirectory() as d:
            fx.write(d, files)
            self.assertTrue(Snapshot(d).fatal_problems)

    def test_rule_ids_unique_and_complete(self):
        ids = [r.id for r in RULES]
        self.assertEqual(len(ids), len(set(ids)))
        for r in RULES:
            self.assertTrue(r.remediation and r.risk and r.frameworks, r.id)

    def test_cli_end_to_end(self):
        with tempfile.TemporaryDirectory() as d, tempfile.TemporaryDirectory() as out:
            fx.write(Path(d) / "run1", fx.weak_tenant())
            code = run_audit.main(["--snapshots", str(Path(d) / "run1"), "--out", out, "--fail-on", "High"])
            self.assertEqual(code, 2)
            files = {p.name for p in (Path(out) / "run1").iterdir()}
            self.assertEqual(files, {"run.json", "snapshot.json", "results.json", "findings.json"})
            run_json = json.loads((Path(out) / "run1" / "run.json").read_text(encoding="utf-8"))
            self.assertEqual(run_json["tenant_name"], "Contoso")


if __name__ == "__main__":
    unittest.main(verbosity=2)
