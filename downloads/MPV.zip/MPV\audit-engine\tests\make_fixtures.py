"""Sinh snapshot mẫu có cùng cấu trúc với đầu ra của 5 collector PowerShell (dữ liệu giả lập, không phải tenant thật)."""
import json
from pathlib import Path

TS = "2026-11-13T09:00:00Z"


def doc(domain, name, summary, data, errors=None, tenant="00000000-0000-0000-0000-000000000001"):
    return {"schema_version": "1.0", "domain": domain, "collector": name, "tenant_id": tenant, "collected_at": TS,
            "pseudonymized": True, "sources": [], "notes": [], "errors": errors or [], "summary": summary, "data": data}


def err(name, hint, status=403, code="X"):
    return {"name": name, "endpoint": "/v1.0/x", "http_status": status, "code": code, "message": "m", "hint": hint}


def weak_tenant():
    """Tenant cấu hình yếu, có P2."""
    users = [
        {"id": "u1", "upn": "user_0001", "user_type": "Member", "account_enabled": True, "days_since_last_sign_in": 200, "days_since_created": 900},
        {"id": "u2", "upn": "user_0002", "user_type": "Member", "account_enabled": True, "days_since_last_sign_in": 3, "days_since_created": 400},
        {"id": "u3", "upn": "user_0003", "user_type": "Guest", "account_enabled": True, "days_since_last_sign_in": None, "days_since_created": 300},
    ]
    identity = doc("Identity", "01_identity", {
        "total_users": 200, "members": 180, "guests": 20, "sign_in_activity_available": True, "stale_days_threshold": 90,
        "stale_enabled_members": 1, "stale_enabled_guests": 1, "risky_users_at_risk": 2, "security_defaults_enabled": False,
        "guest_invite_policy": "everyone", "users_can_create_apps": True, "users_can_create_tenants": True,
        "onprem_sync_enabled": True, "onprem_last_sync": "2026-11-09T09:00:00Z"},
        {"organization": {"display_name": "Contoso"}, "users": users,
         "risky_users": [{"id": "u1", "upn": "user_0001", "risk_level": "high", "risk_state": "atRisk"},
                         {"id": "u2", "upn": "user_0002", "risk_level": "low", "risk_state": "atRisk"}]})

    facts = [
        {"name": "Require MFA admins (report-only)", "state": "enabledForReportingButNotEnforced", "has_exclusions": False, "excluded_users_count": 0},
        {"name": "Block old stuff", "state": "disabled", "has_exclusions": False, "excluded_users_count": 0},
        {"name": "Geo block", "state": "enabled", "has_exclusions": True, "excluded_users_count": 4},
    ]
    ca = doc("ConditionalAccess", "02_conditional_access", {
        "policies_total": 3, "policies_enabled": 1, "policies_report_only": 1, "policies_disabled": 1,
        "mfa_all_users_all_apps": False, "mfa_covers_admin_roles": False, "mfa_for_guests": False,
        "legacy_auth_blocked_all_users": False, "security_info_registration_protected": False,
        "sign_in_risk_policy_enabled": False, "user_risk_policy_enabled": False, "device_compliance_required": False,
        "enabled_policies_with_exclusions": 1}, {"facts": facts})

    active = [
        {"kind": "active", "role": "Global Administrator", "is_privileged": True, "principal_type": "user", "upn": f"admin_{i:04d}",
         "mfa_registered": i > 2, "user_type": "Guest" if i == 1 else "Member", "synced_from_onprem": i == 2,
         "account_enabled": i != 3, "assignment_type": "Assigned", "end_date_time": None} for i in range(1, 8)]
    active.append({"kind": "active", "role": "Application Administrator", "is_privileged": True, "principal_type": "servicePrincipal", "name": "Legacy Backup App"})
    roles_sum = {"global_admin_active_users": 7, "global_admin_permanent_users": 7, "global_admin_eligible_users": 0,
                 "privileged_active_users": 7, "privileged_users_without_mfa": 2, "privileged_guest_users": 1,
                 "privileged_disabled_accounts": 1, "privileged_onprem_synced_accounts": 1, "roles_held_by_service_principals": 1}
    baseline = doc("SecurityBaseline", "03_security_baseline", {
        "mfa": {"mfa_registered_pct": 62.0}, "secure_score_pct": 38.0}, {
        "mfa_registration": {"summary": {}}, "legacy_auth": {
            "performed": True, "lookback_days": 7, "total_events_sampled": 42, "distinct_users": 3,
            "by_protocol": [{"protocol": "IMAP4", "events_sampled": 30}, {"protocol": "SMTP", "events_sampled": 12}],
            "top_users": [{"upn": "user_0010", "events": 30}]},
        "admin_roles": {"summary": roles_sum, "active": active, "eligible": []},
        "authentication_methods_policy": {"methods": [{"id": "Sms", "state": "enabled"}, {"id": "MicrosoftAuthenticator", "state": "enabled"}]}})
    baseline["summary"]["mfa"].update({"users_total": 200, "mfa_registered": 124, "users_only_weak_methods": 31})

    apps = doc("Apps", "04_apps", {
        "app_registrations_total": 3, "apps_with_expired_credential": 1, "apps_with_credential_expiring_soon": 1, "expiring_window_days": 30,
        "apps_with_long_lived_secret": 1, "apps_with_high_risk_application_roles": 1, "third_party_service_principals": 5,
        "third_party_unverified_publisher": 2, "third_party_with_high_risk_roles": 1, "tenant_wide_delegated_grants": 4,
        "tenant_wide_grants_with_high_risk_scopes": 1, "user_consent_mode": "users_can_consent_to_any_app (legacy)",
        "admin_consent_workflow_enabled": False, "sp_activity_data_available": False, "apps_inactive_with_credentials": None},
        {"app_registrations": [
            {"name": "HR Sync", "has_expired_credential": True},
            {"name": "Reporting", "has_expiring_credential": True, "has_long_lived_secret": True},
            {"name": "Mail Relay", "has_granted_high_risk_role": True, "granted_high_risk_roles": ["Microsoft Graph:Mail.Send"]}],
         "third_party_service_principals": [{"name": "Shady CRM", "granted_high_risk_roles": ["Microsoft Graph:Mail.ReadWrite"]}],
         "delegated_grants_tenant_wide": [{"client_name": "Shady CRM", "high_risk_scopes": ["Mail.ReadWrite"]}]})

    licenses = doc("Licenses", "05_licenses", {
        "licensed_disabled_users": 3, "sign_in_activity_available": True, "licensed_inactive_users": 8, "stale_days_threshold": 90,
        "licensed_guests": 0, "skus_with_low_utilization": 1, "users_with_multiple_skus": 5, "skus_suspended_or_warning": 0,
        "available_units_paid_skus": 30},
        {"licenses_to_review": [{"upn": "user_0050", "reasons": ["account_disabled"]}, {"upn": "user_0051", "reasons": ["inactive_over_90_days"]}],
         "skus": [{"name": "Microsoft 365 E3", "purchased_units": 100, "consumed_units": 70, "utilization_pct": 70.0, "status": "Enabled",
                   "suspended_units": 0, "warning_units": 0}],
         "multi_sku_combinations": [{"combination": "Microsoft 365 E3 + Power BI Pro", "users": 5}]})
    return {"01_identity": identity, "02_conditional_access": ca, "03_security_baseline": baseline, "04_apps": apps, "05_licenses": licenses}


def free_tenant():
    """Tenant Entra Free: thiếu P1/P2 -> collector ghi hint=license."""
    lic = lambda n: err(n, "license", 403, "Authentication_RequestFromNonPremiumTenantOrB2CTenant")  # noqa: E731
    identity = doc("Identity", "01_identity", {
        "total_users": 40, "members": 38, "guests": 2, "sign_in_activity_available": False, "risky_users_at_risk": None,
        "security_defaults_enabled": False, "guest_invite_policy": "adminsAndGuestInviters", "users_can_create_apps": False,
        "users_can_create_tenants": False, "onprem_sync_enabled": False},
        {"organization": {"display_name": "SmallCo"}, "users": []},
        errors=[lic("users+signInActivity"), lic("riskyUsers")])
    ca = doc("ConditionalAccess", "02_conditional_access", {}, {}, errors=[lic("conditionalAccessPolicies")])
    baseline = doc("SecurityBaseline", "03_security_baseline", {"mfa": {"available": False}, "secure_score_pct": 71.0}, {
        "legacy_auth": {"performed": True, "by_protocol": []},
        "admin_roles": {"summary": {"global_admin_active_users": 3, "global_admin_permanent_users": None, "global_admin_eligible_users": 0,
                                    "privileged_active_users": 3, "privileged_users_without_mfa": 0, "privileged_guest_users": 0,
                                    "privileged_disabled_accounts": 0, "privileged_onprem_synced_accounts": 0, "roles_held_by_service_principals": 0},
                        "active": [], "eligible": []},
        "authentication_methods_policy": {"methods": [{"id": "Sms", "state": "disabled"}]}},
        errors=[lic("userRegistrationDetails"), lic("roleEligibilitySchedules"), lic("roleAssignmentScheduleInstances"),
                lic("signIns[interactive][IMAP4]"), lic("signIns[interactive][POP3]")])
    apps = doc("Apps", "04_apps", {"app_registrations_total": 2, "apps_with_expired_credential": 0, "apps_with_credential_expiring_soon": 0,
                                   "expiring_window_days": 30, "apps_with_long_lived_secret": 0, "apps_with_high_risk_application_roles": 0,
                                   "third_party_with_high_risk_roles": 0, "tenant_wide_grants_with_high_risk_scopes": 0,
                                   "user_consent_mode": "users_can_consent_low_risk_verified_publishers", "sp_activity_data_available": False},
               {"app_registrations": []})
    licenses = doc("Licenses", "05_licenses", {"licensed_disabled_users": 0, "sign_in_activity_available": False, "licensed_guests": 0,
                                               "skus_with_low_utilization": 0, "users_with_multiple_skus": 0, "skus_suspended_or_warning": 0},
                   {"skus": [], "licenses_to_review": []})
    return {"01_identity": identity, "02_conditional_access": ca, "03_security_baseline": baseline, "04_apps": apps, "05_licenses": licenses}


def write(folder, files):
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    for name, d in files.items():
        (folder / f"{name}.json").write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")
    return folder
