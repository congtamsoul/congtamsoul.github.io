from ..model import fail, na, ok, unknown, warn
from ..registry import rule

LIC = [("licenses", "subscribedSkus")]


def _flagged(snap, reason):
    return [u["upn"] for u in snap.licenses.data.get("licenses_to_review", []) if reason in u.get("reasons", [])
            or any(r.startswith(reason) for r in u.get("reasons", []))]


@rule(id="LIC-001", domain="Licenses", title="License đang gán cho tài khoản đã bị vô hiệu hóa", severity="Low",
      risk="Lãng phí chi phí license và là dấu hiệu quy trình offboarding thiếu bước thu hồi.",
      remediation=["Thu hồi license của tài khoản disabled (sau khi đã sao lưu/chuyển dữ liệu)", "Tự động hóa trong quy trình offboarding"],
      effort="Low", frameworks=["Tối ưu license / FinOps"], sources=["licenses"], needs=LIC, tags=["licensing", "cost"])
def lic_001(snap):
    n = snap.licenses.summary.get("licensed_disabled_users")
    if n is None:
        return unknown("Thiếu số liệu")
    ev = {"licensed_disabled_users": n}
    return ok(ev) if n == 0 else fail(ev, f"{n} tài khoản disabled còn license", affected=_flagged(snap, "account_disabled"))


@rule(id="LIC-002", domain="Licenses", title="License gán cho người dùng bất hoạt", severity="Low",
      risk="Chi phí license không tạo giá trị; có thể bao gồm tài khoản bị bỏ quên.",
      remediation=["Rà soát với quản lý; thu hồi hoặc hạ gói", "Đặt chính sách thu hồi tự động sau N ngày không dùng"],
      effort="Low", frameworks=["Tối ưu license / FinOps"], sources=["licenses"], needs=LIC, tags=["licensing", "cost"])
def lic_002(snap):
    s = snap.licenses.summary
    if not s.get("sign_in_activity_available"):
        return na("Không có signInActivity (cần Entra ID P1) nên không đánh giá được")
    n = s.get("licensed_inactive_users")
    ev = {"licensed_inactive_users": n, "stale_days_threshold": s.get("stale_days_threshold")}
    return ok(ev) if not n else warn(ev, f"{n} user có license nhưng bất hoạt > {s.get('stale_days_threshold')} ngày",
                                     affected=_flagged(snap, "inactive_over_"))


@rule(id="LIC-003", domain="Licenses", title="Guest đang được gán license", severity="Low",
      risk="Guest thường không cần license trả phí; có thể là gán nhầm.",
      remediation=["Gỡ license không cần thiết khỏi guest"], effort="Low", frameworks=["Tối ưu license / FinOps"],
      sources=["licenses"], needs=LIC, tags=["licensing", "guests"])
def lic_003(snap):
    n = snap.licenses.summary.get("licensed_guests")
    if n is None:
        return unknown("Thiếu số liệu")
    ev = {"licensed_guests": n}
    return ok(ev) if n == 0 else warn(ev, f"{n} guest có license", affected=_flagged(snap, "guest_with_license"))


@rule(id="LIC-004", domain="Licenses", title="SKU có tỷ lệ sử dụng thấp (mua nhiều hơn dùng)", severity="Low",
      risk="Mua dư license gây lãng phí chi phí định kỳ.",
      remediation=["Giảm số lượng ở kỳ gia hạn tiếp theo", "Cân nhắc dành slot cho tăng trưởng đã biết"],
      effort="Low", frameworks=["Tối ưu license / FinOps"], sources=["licenses"], needs=LIC, tags=["licensing", "cost"])
def lic_004(snap):
    n = snap.licenses.summary.get("skus_with_low_utilization")
    if n is None:
        return unknown("Thiếu số liệu")
    ev = {"skus_with_low_utilization": n, "available_units_paid_skus": snap.licenses.summary.get("available_units_paid_skus")}
    if n == 0:
        return ok(ev)
    aff = [f'{s["name"]}: dùng {s["consumed_units"]}/{s["purchased_units"]} ({s["utilization_pct"]}%)'
           for s in snap.licenses.data.get("skus", []) if s.get("utilization_pct") is not None
           and s.get("purchased_units", 0) >= 5 and s["utilization_pct"] < 80]
    return warn(ev, "Cần đối chiếu với hợp đồng và kế hoạch tuyển dụng", affected=aff)


@rule(id="LIC-005", domain="Licenses", title="Người dùng giữ nhiều SKU có thể chồng lấp", severity="Low",
      risk="Chồng lấp (ví dụ E3 + E5) có thể là lãng phí; cũng có thể là add-on hợp lệ.",
      remediation=["Xem multi_sku_combinations và xác nhận từng tổ hợp", "Chuẩn hóa gán license theo nhóm"],
      effort="Low", frameworks=["Tối ưu license / FinOps"], sources=["licenses"], needs=LIC, tags=["licensing", "cost"])
def lic_005(snap):
    n = snap.licenses.summary.get("users_with_multiple_skus")
    if n is None:
        return unknown("Thiếu số liệu")
    ev = {"users_with_multiple_skus": n}
    combos = [f'{c["combination"]} ({c["users"]} user)' for c in snap.licenses.data.get("multi_sku_combinations", [])]
    return ok(ev) if n == 0 else warn(ev, "Cần người xác nhận: có thể là add-on hợp lệ", affected=combos)


@rule(id="LIC-006", domain="Licenses", title="SKU ở trạng thái suspended/warning/hết hạn", severity="Medium",
      risk="Subscription bị tạm ngưng hoặc sắp bị ngưng gây mất dịch vụ cho người dùng.",
      remediation=["Kiểm tra thanh toán/gia hạn trong Microsoft 365 admin center"],
      effort="Low", frameworks=["Vận hành license"], sources=["licenses"], needs=LIC, tags=["licensing", "availability"])
def lic_006(snap):
    n = snap.licenses.summary.get("skus_suspended_or_warning")
    if n is None:
        return unknown("Thiếu số liệu")
    ev = {"skus_suspended_or_warning": n}
    if n == 0:
        return ok(ev)
    aff = [f'{s["name"]} (status={s["status"]}, suspended={s["suspended_units"]}, warning={s["warning_units"]})'
           for s in snap.licenses.data.get("skus", []) if s.get("suspended_units") or s.get("warning_units") or s.get("status") != "Enabled"]
    return fail(ev, f"{n} SKU có vấn đề trạng thái", affected=aff)
