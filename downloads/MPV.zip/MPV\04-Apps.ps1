#Requires -Version 7.0
<#
.SYNOPSIS
  Collector 4 - Apps: app registration + hạn secret/cert, quyền Application đã cấp (Graph/Exchange/SharePoint),
  service principal bên thứ ba, delegated consent (tenant-wide / per-user), chính sách user consent.
.NOTES
  Quyền Graph (Application, read-only): Application.Read.All, Directory.Read.All, Policy.Read.All,
  Organization.Read.All, AuditLog.Read.All (cho báo cáo hoạt động service principal - beta, tùy chọn)
  Chỉ đọc quyền Application cấp cho 4 resource API phổ biến (Graph, Exchange Online, SharePoint, Azure AD Graph).
#>
[CmdletBinding()]
param(
    [string]$TenantId,
    [string]$ClientId,
    [string]$OutDir,
    [int]$ExpiringWithinDays = 30,
    [int]$LongLivedSecretDays = 730,
    [int]$InactiveDays = 90,
    [switch]$SkipSpSignInActivity,
    [switch]$Pseudonymize
)
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot 'AuditCommon.psm1') -ErrorAction Stop
Start-AuditCollector -TenantId $TenantId -ClientId $ClientId -OutDir $OutDir -Pseudonymize:$Pseudonymize `
    -Permissions 'Application.Read.All', 'Directory.Read.All', 'Policy.Read.All', 'Organization.Read.All'

Write-Host '[04] Apps collector...' -ForegroundColor Cyan

# ---- Danh sách quyền rủi ro cao (tên quyền, áp dụng cho cả Application và Delegated) ----
$HighRiskApplication = @(
    'Directory.ReadWrite.All', 'RoleManagement.ReadWrite.Directory', 'Application.ReadWrite.All',
    'AppRoleAssignment.ReadWrite.All', 'User.ReadWrite.All', 'Group.ReadWrite.All',
    'Mail.ReadWrite', 'Mail.Send', 'Mail.Read', 'MailboxSettings.ReadWrite',
    'Files.ReadWrite.All', 'Files.Read.All', 'Sites.FullControl.All', 'Sites.ReadWrite.All',
    'Policy.ReadWrite.ConditionalAccess', 'DeviceManagementConfiguration.ReadWrite.All',
    'DeviceManagementManagedDevices.ReadWrite.All', 'DeviceManagementRBAC.ReadWrite.All',
    'full_access_as_app', 'Exchange.ManageAsApp', 'Chat.ReadWrite.All', 'Calendars.ReadWrite'
)
$HighRiskDelegated = @(
    'Directory.AccessAsUser.All', 'Directory.ReadWrite.All', 'User.ReadWrite.All',
    'Mail.ReadWrite', 'Mail.Send', 'Files.ReadWrite.All', 'Sites.FullControl.All',
    'full_access_as_user', 'EWS.AccessAsUser.All', 'RoleManagement.ReadWrite.Directory'
)
$MicrosoftOwnerTenants = @('f8cdef31-a31e-4b4a-93e4-5f571e91255a', '72f988bf-86f1-41af-91ab-2d7cd011db47')

$Resources = [ordered]@{
    'Microsoft Graph'            = '00000003-0000-0000-c000-000000000000'
    'Exchange Online'            = '00000002-0000-0ff1-ce00-000000000000'
    'SharePoint Online'          = '00000003-0000-0ff1-ce00-000000000000'
    'Azure AD Graph (deprecated)' = '00000002-0000-0000-c000-000000000000'
}

# ---- Lấy dữ liệu ----
$org = Select-AuditSingle (Invoke-GraphSafe -Name 'organization' -Uri '/v1.0/organization')
$tenantGuid = if ($org) { $org.id } else { $TenantId }

$appSelect = 'id,appId,displayName,createdDateTime,signInAudience,publisherDomain,verifiedPublisher,passwordCredentials,keyCredentials,requiredResourceAccess'
$apps = Invoke-GraphSafe -Name 'applications' -Paged -Uri ('/v1.0/applications?$select={0}&$top=999' -f $appSelect)
$spSelect = 'id,appId,displayName,servicePrincipalType,accountEnabled,appOwnerOrganizationId,signInAudience,tags,verifiedPublisher'
$sps = Invoke-GraphSafe -Name 'servicePrincipals' -Paged -Uri ('/v1.0/servicePrincipals?$select={0}&$top=999' -f $spSelect)
if ($null -eq $apps) { $apps = @() }
if ($null -eq $sps)  { $sps = @() }

$spById = @{}; $spByAppId = @{}
foreach ($sp in $sps) { $spById[$sp.id] = $sp; $spByAppId[$sp.appId] = $sp }

# ---- Map id -> tên quyền cho từng resource + quyền Application đã được cấp ----
$idMap = @{}                                   # resourceAppId -> (id -> value)
$grantsByPrincipal = @{}                       # principalId(SP) -> list "Resource:Role"
foreach ($resName in $Resources.Keys) {
    $resAppId = $Resources[$resName]
    $resSp = $spByAppId[$resAppId]
    if (-not $resSp) { continue }
    $detail = Invoke-GraphSafe -Name "resource[$resName]" -Uri ('/v1.0/servicePrincipals/{0}?$select=id,appRoles,oauth2PermissionScopes' -f $resSp.id)
    if ($detail) {
        $m = @{}
        foreach ($r in (ConvertTo-AuditArray $detail.appRoles))               { $m[$r.id] = $r.value }
        foreach ($sc in (ConvertTo-AuditArray $detail.oauth2PermissionScopes)) { $m[$sc.id] = $sc.value }
        $idMap[$resAppId] = $m
    }
    $assigned = Invoke-GraphSafe -Name "appRoleAssignedTo[$resName]" -Paged -Uri ('/v1.0/servicePrincipals/{0}/appRoleAssignedTo?$top=999' -f $resSp.id)
    if ($null -ne $assigned) {
        foreach ($a in $assigned) {
            if ($a.principalType -ne 'ServicePrincipal') { continue }
            $roleName = if ($idMap[$resAppId] -and $idMap[$resAppId][$a.appRoleId]) { $idMap[$resAppId][$a.appRoleId] } else { "$($a.appRoleId)" }
            if (-not $grantsByPrincipal.ContainsKey($a.principalId)) {
                $grantsByPrincipal[$a.principalId] = [System.Collections.Generic.List[object]]::new()
            }
            $grantsByPrincipal[$a.principalId].Add([ordered]@{ resource = $resName; role = $roleName; granted = $a.createdDateTime })
        }
    }
}

# ---- Hoạt động đăng nhập của service principal (beta, tùy chọn) ----
$spActivity = @{}
if (-not $SkipSpSignInActivity) {
    $act = Invoke-GraphSafe -Name 'servicePrincipalSignInActivities(beta)' -Paged -Uri '/beta/reports/servicePrincipalSignInActivities?$top=999'
    if ($null -ne $act) {
        foreach ($x in $act) {
            $dates = @(
                $x.lastSignInActivity.lastSignInDateTime,
                $x.delegatedClientSignInActivity.lastSignInDateTime,
                $x.delegatedResourceSignInActivity.lastSignInDateTime,
                $x.applicationAuthenticationClientSignInActivity.lastSignInDateTime,
                $x.applicationAuthenticationResourceSignInActivity.lastSignInDateTime
            ) | ForEach-Object { ConvertTo-AuditUtcDate $_ } | Where-Object { $_ }
            if ($dates) { $spActivity[$x.appId] = ($dates | Sort-Object -Descending | Select-Object -First 1) }
        }
    }
}
$activityAvailable = ($spActivity.Count -gt 0)

# ---- App registrations ----
$now = [datetime]::UtcNow
function ConvertTo-CredRecord($c, [string]$type) {
    $end   = ConvertTo-AuditUtcDate $c.endDateTime
    $start = ConvertTo-AuditUtcDate $c.startDateTime
    [ordered]@{
        type           = $type
        key_id         = $c.keyId
        name           = $c.displayName
        start          = if ($start) { $start.ToString('o') } else { $null }
        end            = if ($end) { $end.ToString('o') } else { $null }
        days_to_expiry = if ($end) { [int][math]::Floor(($end - $now).TotalDays) } else { $null }
        lifetime_days  = if ($end -and $start) { [int][math]::Floor(($end - $start).TotalDays) } else { $null }
    }
}

$appRecords = @(foreach ($a in $apps) {
        $creds = @()
        foreach ($s in (ConvertTo-AuditArray $a.passwordCredentials)) { $creds += ConvertTo-CredRecord $s 'secret' }
        foreach ($k in (ConvertTo-AuditArray $a.keyCredentials))      { $creds += ConvertTo-CredRecord $k 'certificate' }
        $secrets = @($creds | Where-Object { $_.type -eq 'secret' })
        $certs   = @($creds | Where-Object { $_.type -eq 'certificate' })

        # Quyền khai báo trong manifest
        $reqApp = @(); $reqDel = @()
        foreach ($rra in (ConvertTo-AuditArray $a.requiredResourceAccess)) {
            $map = $idMap[$rra.resourceAppId]
            foreach ($ra in (ConvertTo-AuditArray $rra.resourceAccess)) {
                $nm = if ($map -and $map[$ra.id]) { $map[$ra.id] } else { "$($rra.resourceAppId):$($ra.id)" }
                if ($ra.type -eq 'Role') { $reqApp += $nm } else { $reqDel += $nm }
            }
        }
        # Quyền Application đã thực sự được cấp (admin consent)
        $sp = $spByAppId[$a.appId]
        $granted = @(); if ($sp -and $grantsByPrincipal.ContainsKey($sp.id)) { $granted = @($grantsByPrincipal[$sp.id]) }
        $grantedHigh = @($granted | Where-Object { $_.role -in $HighRiskApplication })
        $lastAct = if ($activityAvailable -and $spActivity.ContainsKey($a.appId)) { $spActivity[$a.appId] } else { $null }
        $daysIdle = if ($lastAct) { [int][math]::Floor(($now - $lastAct).TotalDays) } else { $null }

        [ordered]@{
            id                       = $a.id
            app_id                   = $a.appId
            name                     = $a.displayName
            created                  = $a.createdDateTime
            sign_in_audience         = $a.signInAudience
            verified_publisher       = [bool]$a.verifiedPublisher.verifiedPublisherId
            secrets_count            = $secrets.Count
            certificates_count       = $certs.Count
            has_no_credentials       = ($creds.Count -eq 0)
            uses_secret_only         = ($secrets.Count -gt 0 -and $certs.Count -eq 0)
            has_expired_credential   = (@($creds | Where-Object { $null -ne $_.days_to_expiry -and $_.days_to_expiry -lt 0 }).Count -gt 0)
            has_expiring_credential  = (@($creds | Where-Object { $null -ne $_.days_to_expiry -and $_.days_to_expiry -ge 0 -and $_.days_to_expiry -le $ExpiringWithinDays }).Count -gt 0)
            has_long_lived_secret    = (@($secrets | Where-Object { $null -ne $_.lifetime_days -and $_.lifetime_days -gt $LongLivedSecretDays }).Count -gt 0)
            credentials              = $creds
            requested_application_permissions = $reqApp
            requested_delegated_permissions   = $reqDel
            granted_application_roles         = $granted
            granted_high_risk_roles           = @($grantedHigh | ForEach-Object { "{0}:{1}" -f $_.resource, $_.role })
            has_granted_high_risk_role        = ($grantedHigh.Count -gt 0)
            last_sign_in_activity    = if ($lastAct) { $lastAct.ToString('o') } else { $null }
            days_since_last_activity = $daysIdle
            inactive_with_credentials = ($activityAvailable -and $creds.Count -gt 0 -and ($null -eq $daysIdle -or $daysIdle -gt $InactiveDays))
        }
    })

# ---- Service principals (tóm tắt + bên thứ ba) ----
$spRecords = @(foreach ($sp in $sps) {
        if ($sp.servicePrincipalType -ne 'Application') { continue }
        $owner = $sp.appOwnerOrganizationId
        $isThirdParty = ($owner -and $owner -ne $tenantGuid -and $owner -notin $MicrosoftOwnerTenants)
        if (-not $isThirdParty) { continue }
        $g = @(); if ($grantsByPrincipal.ContainsKey($sp.id)) { $g = @($grantsByPrincipal[$sp.id]) }
        [ordered]@{
            id                    = $sp.id
            app_id                = $sp.appId
            name                  = $sp.displayName
            owner_tenant_id       = $owner
            account_enabled       = $sp.accountEnabled
            verified_publisher    = [bool]$sp.verifiedPublisher.verifiedPublisherId
            granted_application_roles = @($g | ForEach-Object { "{0}:{1}" -f $_.resource, $_.role })
            granted_high_risk_roles   = @($g | Where-Object { $_.role -in $HighRiskApplication } | ForEach-Object { "{0}:{1}" -f $_.resource, $_.role })
        }
    })

# ---- Delegated consent ----
$grants = Invoke-GraphSafe -Name 'oauth2PermissionGrants' -Paged -Uri '/v1.0/oauth2PermissionGrants'
$tenantWide = @(); $perUser = @()
if ($null -ne $grants) {
    $tenantWide = @(foreach ($g in ($grants | Where-Object { $_.consentType -eq 'AllPrincipals' })) {
            $sp = $spById[$g.clientId]
            $scopes = @(("$($g.scope)" -split '\s+') | Where-Object { $_ })
            $owner = $sp.appOwnerOrganizationId
            [ordered]@{
                client_sp_id    = $g.clientId
                client_name     = $sp.displayName
                client_app_id   = $sp.appId
                third_party     = [bool]($owner -and $owner -ne $tenantGuid -and $owner -notin $MicrosoftOwnerTenants)
                scopes          = $scopes
                high_risk_scopes = @($scopes | Where-Object { $_ -in $HighRiskDelegated })
            }
        })
    $perUserGroups = $grants | Where-Object { $_.consentType -eq 'Principal' } | Group-Object { $_.clientId }
    $perUser = @(foreach ($grp in $perUserGroups) {
            $sp = $spById[$grp.Name]
            $scopes = @($grp.Group | ForEach-Object { "$($_.scope)" -split '\s+' } | Where-Object { $_ } | Sort-Object -Unique)
            [ordered]@{
                client_sp_id     = $grp.Name
                client_name      = $sp.displayName
                users_consented  = $grp.Count
                scopes           = $scopes
                high_risk_scopes = @($scopes | Where-Object { $_ -in $HighRiskDelegated })
            }
        })
}

# ---- Chính sách consent / tạo app ----
$authz = Select-AuditSingle (Invoke-GraphSafe -Name 'authorizationPolicy' -Uri '/v1.0/policies/authorizationPolicy')
$adminConsent = Invoke-GraphSafe -Name 'adminConsentRequestPolicy' -Uri '/v1.0/policies/adminConsentRequestPolicy'
$grantPolicies = ConvertTo-AuditArray $authz.defaultUserRolePermissions.permissionGrantPoliciesAssigned
$consentMode = 'unknown'
if ($authz) {
    if ($grantPolicies.Count -eq 0) { $consentMode = 'users_cannot_consent' }
    elseif (@($grantPolicies | Where-Object { $_ -match 'legacy' }).Count -gt 0) { $consentMode = 'users_can_consent_to_any_app (legacy)' }
    elseif (@($grantPolicies | Where-Object { $_ -match 'low' }).Count -gt 0) { $consentMode = 'users_can_consent_low_risk_verified_publishers' }
    else { $consentMode = 'custom' }
}

# ---- Tổng hợp ----
$summary = [ordered]@{
    app_registrations_total             = $appRecords.Count
    apps_with_expired_credential        = @($appRecords | Where-Object { $_.has_expired_credential }).Count
    apps_with_credential_expiring_soon  = @($appRecords | Where-Object { $_.has_expiring_credential }).Count
    expiring_window_days                = $ExpiringWithinDays
    apps_with_long_lived_secret         = @($appRecords | Where-Object { $_.has_long_lived_secret }).Count
    apps_using_secret_only              = @($appRecords | Where-Object { $_.uses_secret_only }).Count
    apps_without_credentials            = @($appRecords | Where-Object { $_.has_no_credentials }).Count
    apps_with_high_risk_application_roles = @($appRecords | Where-Object { $_.has_granted_high_risk_role }).Count
    apps_inactive_with_credentials      = if ($activityAvailable) { @($appRecords | Where-Object { $_.inactive_with_credentials }).Count } else { $null }
    sp_activity_data_available          = $activityAvailable
    service_principals_total            = $sps.Count
    third_party_service_principals      = $spRecords.Count
    third_party_unverified_publisher    = @($spRecords | Where-Object { -not $_.verified_publisher }).Count
    third_party_with_high_risk_roles    = @($spRecords | Where-Object { $_.granted_high_risk_roles.Count -gt 0 }).Count
    tenant_wide_delegated_grants        = $tenantWide.Count
    tenant_wide_grants_with_high_risk_scopes = @($tenantWide | Where-Object { $_.high_risk_scopes.Count -gt 0 }).Count
    per_user_consented_apps             = $perUser.Count
    per_user_consented_apps_high_risk   = @($perUser | Where-Object { $_.high_risk_scopes.Count -gt 0 }).Count
    user_consent_mode                   = $consentMode
    users_can_create_apps               = $authz.defaultUserRolePermissions.allowedToCreateApps
    admin_consent_workflow_enabled      = $adminConsent.isEnabled
}

$data = [ordered]@{
    app_registrations         = $appRecords
    third_party_service_principals = $spRecords
    delegated_grants_tenant_wide   = $tenantWide
    delegated_grants_per_user      = $perUser
    consent_policy = [ordered]@{
        user_consent_mode              = $consentMode
        permission_grant_policies      = $grantPolicies
        users_can_create_apps          = $authz.defaultUserRolePermissions.allowedToCreateApps
        admin_consent_request_policy   = $adminConsent
    }
    high_risk_application_roles_list = $HighRiskApplication
    high_risk_delegated_scopes_list  = $HighRiskDelegated
}
$notes = @(
    'Chỉ phân tích quyền Application cấp cho Graph, Exchange Online, SharePoint Online, Azure AD Graph; resource API khác chưa được quét.',
    'Danh sách "high risk" là heuristic, có thể chỉnh trong script - cần người đánh giá theo ngữ cảnh.',
    'Chưa kiểm tra owner của từng app (cần 1 call/app); có thể thêm sau nếu tenant nhỏ.',
    'last_sign_in_activity dùng endpoint beta; nếu lỗi, các chỉ số "inactive" sẽ là null (không kết luận).',
    'Secret của app KHÔNG bao giờ được đọc (Graph không trả giá trị secret), chỉ có metadata và ngày hết hạn.'
)
$result = Save-AuditSnapshot -Domain 'Apps' -Name '04_apps' -Data $data -Summary $summary -Notes $notes `
    -Sources @('/v1.0/applications', '/v1.0/servicePrincipals', '/v1.0/servicePrincipals/{id}/appRoleAssignedTo',
    '/v1.0/oauth2PermissionGrants', '/v1.0/policies/authorizationPolicy', '/v1.0/policies/adminConsentRequestPolicy',
    '/beta/reports/servicePrincipalSignInActivities')
Write-Host ("    -> {0} app, {1} hết hạn, {2} sắp hết hạn, {3} có quyền rủi ro cao, {4} lỗi/cảnh báo" -f `
        $summary.app_registrations_total, $summary.apps_with_expired_credential, $summary.apps_with_credential_expiring_soon,
    $summary.apps_with_high_risk_application_roles, $result.ErrorCount)
$result
