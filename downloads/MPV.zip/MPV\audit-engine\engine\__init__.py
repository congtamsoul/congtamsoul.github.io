"""M365 audit rules engine - đọc snapshot JSON từ collector, sinh findings. Không dùng LLM."""
ENGINE_VERSION = "0.1.0"
RULESET_VERSION = "2026.11.1"
