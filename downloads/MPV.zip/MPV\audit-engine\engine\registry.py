"""Đăng ký rule bằng decorator. Mỗi rule là một hàm Python nhận snapshot và trả về Outcome."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

from .model import SEVERITIES


@dataclass(frozen=True)
class Need:
    """Rule cần endpoint này của collector chạy thành công thì mới có nghĩa."""
    source: str      # identity | ca | baseline | apps | licenses
    endpoint: str    # tên trong mục errors của snapshot, ví dụ 'userRegistrationDetails'


@dataclass
class Rule:
    id: str
    domain: str
    title: str
    severity: str
    risk: str
    remediation: list[str]
    effort: str
    frameworks: list[str]
    sources: list[str]
    needs: list[Need]
    tags: list[str]
    fn: Callable


RULES: list[Rule] = []


def rule(*, id, domain, title, severity, risk, remediation, effort,
         frameworks=(), sources=(), needs=(), tags=()):
    def deco(fn):
        if any(r.id == id for r in RULES):
            raise ValueError(f"Trùng rule id: {id}")
        if severity not in SEVERITIES:
            raise ValueError(f"{id}: severity không hợp lệ: {severity}")
        RULES.append(Rule(id=id, domain=domain, title=title, severity=severity, risk=risk,
                          remediation=list(remediation), effort=effort, frameworks=list(frameworks),
                          sources=list(sources), needs=[Need(*n) for n in needs], tags=list(tags), fn=fn))
        return fn
    return deco
