﻿# MPV - Microsoft 365 audit project

This package contains the PowerShell collectors, shared module, Python audit engine, tests, and project documentation.

## Requirements

- PowerShell 7 or later
- Python 3.10 or later (the audit engine uses only the Python standard library)
- Microsoft.Graph.Authentication PowerShell module v2.x
- An appropriately configured Microsoft Entra app registration and admin-consented, read-only Microsoft Graph application permissions; see `README.md`

## Important data exclusions

This public source package intentionally omits `.audit-secrets/`, `snapshots/`, `audit-engine/out/`, and Python cache files. Those directories can contain credentials, tenant identifiers, user data, or audit results. Generate fresh credentials and snapshots in your own authorized environment.

The organization-specific OneDrive module search path in `AuditCommon.psm1` was removed; standard PowerShell module paths remain supported.

## Start here

Read `README.md` for collector setup and `audit-engine/README.md` for running the rules engine and tests. Run first in a lab tenant and review the required Graph permissions before using it in production.