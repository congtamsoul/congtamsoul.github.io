"""Nạp 5 file snapshot của collector, kiểm tra tính nhất quán, và dựng snapshot hợp nhất."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

from .model import dig

FILES = {
    "identity": "01_identity.json",
    "ca": "02_conditional_access.json",
    "baseline": "03_security_baseline.json",
    "apps": "04_apps.json",
    "licenses": "05_licenses.json",
}


class Source:
    """Một file snapshot của collector."""

    def __init__(self, key: str, folder: Path):
        self.key = key
        self.filename = FILES[key]
        self.path = folder / self.filename
        self.doc = None
        self.sha256 = None
        self.load_error = None
        if self.path.exists():
            raw = self.path.read_bytes()
            self.sha256 = hashlib.sha256(raw).hexdigest()
            try:
                self.doc = json.loads(raw.decode("utf-8-sig"))   # utf-8-sig: chịu được file có BOM
            except Exception as exc:  # noqa: BLE001
                self.load_error = str(exc)

    @property
    def present(self): return self.doc is not None
    @property
    def summary(self): return (self.doc or {}).get("summary") or {}
    @property
    def data(self): return (self.doc or {}).get("data") or {}
    @property
    def errors(self): return (self.doc or {}).get("errors") or []
    @property
    def collected_at(self): return (self.doc or {}).get("collected_at")

    def state(self, endpoint: str) -> str:
        """ok | license | permission | not_found | error | missing"""
        if not self.present:
            return "missing"
        hits = [e for e in self.errors if e.get("name") == endpoint]
        if not hits:
            return "ok"
        hints = {e.get("hint") for e in hits}
        for h in ("license", "permission", "not_found"):
            if h in hints:
                return h
        return "error"


class Snapshot:
    def __init__(self, folder: str | Path, tenant_name: str | None = None):
        self.folder = Path(folder)
        self.sources = {k: Source(k, self.folder) for k in FILES}
        self.manifest = self._read_manifest()
        self.problems: list[str] = []
        self._validate()
        self.tenant_id = next((s.doc.get("tenant_id") for s in self.sources.values() if s.present), None)
        self.tenant_name = tenant_name or dig(self.identity.data, "organization", "display_name") or self.tenant_id
        self.pseudonymized = any(s.doc.get("pseudonymized") for s in self.sources.values() if s.present)

    identity = property(lambda self: self.sources["identity"])
    ca = property(lambda self: self.sources["ca"])
    baseline = property(lambda self: self.sources["baseline"])
    apps = property(lambda self: self.sources["apps"])
    licenses = property(lambda self: self.sources["licenses"])

    def _read_manifest(self):
        p = self.folder / "_manifest.json"
        if p.exists():
            try:
                return json.loads(p.read_text(encoding="utf-8-sig"))
            except Exception:  # noqa: BLE001
                return None
        return None

    def _validate(self):
        present = [s for s in self.sources.values() if s.present]
        for s in self.sources.values():
            if s.load_error:
                self.problems.append(f"{s.filename}: không đọc được JSON ({s.load_error})")
            elif not s.present:
                self.problems.append(f"{s.filename}: thiếu file - các rule phụ thuộc sẽ ở trạng thái unknown")
        if len({s.doc.get("tenant_id") for s in present}) > 1:
            self.problems.append("Các file thuộc nhiều tenant_id khác nhau - dừng lại và kiểm tra thư mục snapshot")
        if len({bool(s.doc.get("pseudonymized")) for s in present}) > 1:
            self.problems.append("Trộn snapshot đã và chưa pseudonymize")
        for s in present:
            if s.doc.get("schema_version") != "1.0":
                self.problems.append(f"{s.filename}: schema_version={s.doc.get('schema_version')} (engine hỗ trợ 1.0)")

    @property
    def fatal_problems(self):
        return [p for p in self.problems if "nhiều tenant_id" in p or "Trộn snapshot" in p]

    def to_dict(self, run_id: str) -> dict:
        """Snapshot hợp nhất: chỉ gồm summary (facts) + khả năng truy cập từng endpoint + dấu vân tay file gốc.
        Dữ liệu chi tiết (danh sách user...) vẫn nằm ở file gốc, truy vết qua sha256."""
        availability = {}
        for k, s in self.sources.items():
            if s.present and s.errors:
                availability[k] = {e["name"]: {"state": s.state(e["name"]), "http_status": e.get("http_status"),
                                               "code": e.get("code")} for e in s.errors}
        return {
            "run_id": run_id,
            "tenant_id": self.tenant_id,
            "tenant_name": self.tenant_name,
            "pseudonymized": self.pseudonymized,
            "facts": {k: s.summary for k, s in self.sources.items() if s.present},
            "availability_issues": availability,
            "files": {s.filename: {"sha256": s.sha256, "collected_at": s.collected_at} for s in self.sources.values() if s.present},
            "problems": self.problems,
        }
