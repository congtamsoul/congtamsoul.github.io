# M365 Audit Collectors (read-only)

Bộ collector PowerShell 7 thu thập dữ liệu cấu hình M365/Entra/Intune-liên quan qua Microsoft Graph và ghi ra snapshot JSON.
**Chỉ gọi GET.** Không có LLM trong vòng thu thập. Tầng rules engine + agent đọc các file JSON này ở bước sau.

> **Trạng thái:** script được viết và rà soát tĩnh, **chưa chạy trên tenant thật** (môi trường soạn thảo không có PowerShell).
> Hãy chạy thử trên tenant lab trước khi dùng cho khách. Các điểm dễ cần chỉnh: giá trị `clientAppType` của sign-in log,
> endpoint beta, `$expand=principal` của role assignment, tên thuộc tính khác nhau giữa các phiên bản Graph.

## Cấu trúc

| File | Vai trò |
|---|---|
| `AuditCommon.psm1` | Kết nối (client secret), phân trang, retry 429/5xx, ghi lỗi, pseudonymize, cache users, ghi snapshot |
| `01-Identity.ps1` | Users, guests, tài khoản bất hoạt, tenant/domain, security defaults, chính sách guest & tạo app, risky users |
| `02-ConditionalAccess.ps1` | Policy thô + facts (MFA, block legacy auth, risk, device, guests, exclusions), named locations, auth strengths |
| `03-SecurityBaseline.ps1` | Đăng ký MFA, legacy auth thực tế (sign-in log), admin roles (+PIM), auth methods policy, Secure Score |
| `04-Apps.ps1` | App registrations (hạn secret/cert), quyền Application đã cấp, app bên thứ ba, delegated consent, consent policy |
| `05-Licenses.ps1` | SKU đã mua/đã gán/còn trống, license trên tài khoản bất hoạt/disabled/guest, SKU chồng lấp |
| `Run-Collectors.ps1` | Điều phối: kết nối một lần, chạy theo thứ tự, ghi `_manifest.json` |

## Chuẩn bị

```powershell
Install-Module Microsoft.Graph.Authentication -Scope CurrentUser   # v2.x, chỉ cần module này
```

**Quyền Graph (loại *Application*, cần admin consent, đều read-only):**

| Quyền | Dùng cho |
|---|---|
| `User.Read.All`, `Directory.Read.All`, `Organization.Read.All`, `Domain.Read.All` | 01, 03, 04, 05 |
| `AuditLog.Read.All` | signInActivity, sign-in logs, hoạt động service principal |
| `Policy.Read.All` | CA, authorization/auth methods/consent policy |
| `Reports.Read.All` | userRegistrationDetails (MFA) |
| `RoleManagement.Read.Directory` | role definitions/assignments/PIM |
| `Application.Read.All` | applications, service principals, appRoleAssignedTo |
| `SecurityEvents.Read.All` | Secure Score |
| `IdentityRiskyUser.Read.All` | Risky users (cần Entra P2) |

Kiểm tra lại tên quyền trên Microsoft Graph permissions reference vì Microsoft thường điều chỉnh. Thiếu quyền hoặc thiếu license
(P1/P2) **không làm script dừng**: endpoint lỗi được ghi vào mục `errors` (kèm `hint` = `license` / `permission` / `not_found`).

## Chạy

```powershell
# Nhập secret không để lại trong history
$env:M365_CLIENT_SECRET = Read-Host 'Client secret' -MaskInput

./Run-Collectors.ps1 -TenantId <tenant-guid> -ClientId <app-guid> -Pseudonymize
# Chạy một phần:
./Run-Collectors.ps1 -TenantId <guid> -ClientId <guid> -Only Identity,ConditionalAccess
# Bỏ sign-in log (nhanh hơn / tenant không có P1):
./Run-Collectors.ps1 -TenantId <guid> -ClientId <guid> -SkipSignInLogs
# Thêm sign-in non-interactive (beta) để bắt legacy auth đầy đủ hơn:
./Run-Collectors.ps1 -TenantId <guid> -ClientId <guid> -IncludeNonInteractive
```

Mỗi collector cũng chạy độc lập: `./01-Identity.ps1 -TenantId ... -ClientId ... -OutDir ./out`.

## Đầu ra

```
snapshots/<tenant-id>/<yyyyMMdd-HHmmss>/
  01_identity.json  02_conditional_access.json  03_security_baseline.json
  04_apps.json      05_licenses.json
  _manifest.json    (trạng thái từng collector: ok | partial | failed)
  _alias_map.json   (chỉ khi -Pseudonymize; chứa PII gốc, GIỮ CỤC BỘ)
```

Mỗi file: `schema_version, domain, collector, tenant_id, collected_at, pseudonymized, sources, notes, errors, summary, data`.
`summary` chứa **facts** (số liệu, cờ true/false), không phải kết luận; việc đánh giá thuộc về rules engine.

## Bảo mật & vận hành

- **Client secret:** lấy từ `$env:M365_CLIENT_SECRET` hoặc hỏi nhập; không ghi vào file/log. Secret có hạn, hãy đặt lịch xoay vòng
  và dùng secret riêng cho từng giai đoạn/khách nếu có thể. Khi chạy cho nhiều khách, cân nhắc chuyển sang certificate + Key Vault.
- `-Pseudonymize` thay UPN/tên người dùng bằng `user_0001`... trước khi ghi snapshot. Chỉ snapshot đã pseudonymize mới nên đưa vào LLM.
  Lưu ý GUID object ID, tên app, tên policy vẫn xuất hiện nguyên văn.
- Thư mục `snapshots/` chứa dữ liệu khách hàng: thêm vào `.gitignore`, mã hóa ổ đĩa, có chính sách xóa sau X ngày.
- Chỉ chạy khi đã có văn bản ủy quyền/NDA của khách.

## Giới hạn đã biết

- Sign-in log chỉ giữ ~30 ngày; legacy auth chỉ lấy mẫu (`-MaxPagesPerProtocol`), `truncated=true` nghĩa là còn nhiều hơn.
- Chưa mở rộng thành viên của nhóm đang giữ admin role; chưa kiểm tra owner của từng app.
- Quyền Application chỉ quét cho Graph, Exchange Online, SharePoint Online, Azure AD Graph.
- Chưa có Exchange Online (SPF/DKIM/DMARC, transport rules, auto-forward) và Intune: các domain này cần collector riêng (Exchange Online PowerShell / DNS).
- Danh sách quyền "rủi ro cao" trong `04-Apps.ps1` là heuristic, hãy chỉnh theo chính sách của bạn.
