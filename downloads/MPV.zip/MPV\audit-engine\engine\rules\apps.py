from ..model import dig, fail, na, ok, unknown, warn
from ..registry import rule

APPS = [("apps", "applications")]


def _names(snap, flag):
    return [a["name"] for a in snap.apps.data.get("app_registrations", []) if a.get(flag)]


@rule(id="APP-001", domain="Apps", title="App registration có secret/certificate đã hết hạn", severity="Medium",
      risk="Credential hết hạn gây gián đoạn dịch vụ; credential cũ không dọn là rác cấu hình và rủi ro tồn dư.",
      remediation=["Xác định app còn dùng: xoay vòng credential", "App không dùng: xóa credential hoặc xóa app"],
      effort="Low", frameworks=["Quản trị workload identity"], sources=["apps"], needs=APPS, tags=["apps", "credentials"])
def app_001(snap):
    n = snap.apps.summary.get("apps_with_expired_credential")
    if n is None:
        return unknown("Thiếu số liệu")
    ev = {"apps_with_expired_credential": n, "app_registrations_total": snap.apps.summary.get("app_registrations_total")}
    return ok(ev) if n == 0 else fail(ev, f"{n} app có credential đã hết hạn", affected=_names(snap, "has_expired_credential"))


@rule(id="APP-002", domain="Apps", title="Credential của app sắp hết hạn", severity="Medium",
      risk="Hết hạn không báo trước gây sự cố ngừng dịch vụ (tích hợp, automation, SSO).",
      remediation=["Lên lịch xoay vòng trước hạn", "Thiết lập cảnh báo hết hạn credential tự động"],
      effort="Low", frameworks=["Vận hành workload identity"], sources=["apps"], needs=APPS, tags=["apps", "availability"])
def app_002(snap):
    s = snap.apps.summary
    n = s.get("apps_with_credential_expiring_soon")
    if n is None:
        return unknown("Thiếu số liệu")
    ev = {"apps_expiring": n, "window_days": s.get("expiring_window_days")}
    return ok(ev) if n == 0 else warn(ev, f"{n} app có credential hết hạn trong {s.get('expiring_window_days')} ngày",
                                      affected=_names(snap, "has_expiring_credential"))


@rule(id="APP-003", domain="Apps", title="App dùng client secret thời hạn quá dài", severity="Low",
      risk="Secret sống lâu tăng thời gian rủi ro nếu bị lộ.",
      remediation=["Rút ngắn thời hạn secret", "Ưu tiên certificate hoặc managed identity/federated credential"],
      effort="Medium", frameworks=["Microsoft - best practices cho app credentials"], sources=["apps"], needs=APPS, tags=["apps", "credentials"])
def app_003(snap):
    n = snap.apps.summary.get("apps_with_long_lived_secret")
    if n is None:
        return unknown("Thiếu số liệu")
    ev = {"apps_with_long_lived_secret": n}
    return ok(ev) if n == 0 else warn(ev, f"{n} app có secret thời hạn dài", affected=_names(snap, "has_long_lived_secret"))


@rule(id="APP-004", domain="Apps", title="App registration của tổ chức được cấp quyền Application rủi ro cao", severity="High",
      risk="Quyền Application (không cần người dùng) như Mail.ReadWrite hay Directory.ReadWrite.All cho phép truy cập rộng.",
      remediation=["Xác minh nhu cầu từng quyền; thu hẹp xuống quyền tối thiểu", "Dùng RSC / Sites.Selected thay vì quyền toàn tenant",
                   "Ghi owner chịu trách nhiệm cho app"],
      effort="Medium", frameworks=["Least privilege cho workload identity"], sources=["apps"], needs=APPS, tags=["apps", "permissions"])
def app_004(snap):
    n = snap.apps.summary.get("apps_with_high_risk_application_roles")
    if n is None:
        return unknown("Thiếu số liệu")
    ev = {"apps_with_high_risk_application_roles": n}
    if n == 0:
        return ok(ev)
    aff = [f'{a["name"]}: {", ".join(a.get("granted_high_risk_roles", []))}' for a in snap.apps.data.get("app_registrations", []) if a.get("has_granted_high_risk_role")]
    return warn(ev, "Danh sách 'rủi ro cao' mang tính heuristic - cần người xác nhận theo ngữ cảnh", affected=aff)


@rule(id="APP-005", domain="Apps", title="App bên thứ ba được cấp quyền Application rủi ro cao", severity="High",
      risk="Ứng dụng của nhà cung cấp ngoài có quyền rộng vào dữ liệu tenant là rủi ro chuỗi cung ứng.",
      remediation=["Rà soát nhà cung cấp và nhu cầu", "Thu hồi quyền không cần thiết", "Ưu tiên app có verified publisher"],
      effort="Medium", frameworks=["Quản trị app bên thứ ba"], sources=["apps"], needs=[("apps", "servicePrincipals")], tags=["apps", "third-party"])
def app_005(snap):
    s = snap.apps.summary
    n = s.get("third_party_with_high_risk_roles")
    if n is None:
        return unknown("Thiếu số liệu")
    ev = {"third_party_with_high_risk_roles": n, "third_party_unverified_publisher": s.get("third_party_unverified_publisher"),
          "third_party_service_principals": s.get("third_party_service_principals")}
    if n == 0:
        return ok(ev)
    aff = [f'{sp["name"]}: {", ".join(sp["granted_high_risk_roles"])}' for sp in snap.apps.data.get("third_party_service_principals", []) if sp.get("granted_high_risk_roles")]
    return fail(ev, f"{n} app bên thứ ba có quyền Application rủi ro cao", affected=aff)


@rule(id="APP-006", domain="Apps", title="Admin consent toàn tenant cho quyền delegated rủi ro cao", severity="High",
      risk="Consent toàn tenant áp dụng cho mọi người dùng; ứng dụng độc hại sau consent truy cập dữ liệu của tất cả.",
      remediation=["Xem lại từng grant AllPrincipals trong Enterprise apps > Permissions", "Thu hồi grant không cần thiết"],
      effort="Medium", frameworks=["Quản trị consent ứng dụng"], sources=["apps"], needs=[("apps", "oauth2PermissionGrants")], tags=["apps", "consent"])
def app_006(snap):
    n = snap.apps.summary.get("tenant_wide_grants_with_high_risk_scopes")
    if n is None:
        return unknown("Thiếu số liệu")
    ev = {"tenant_wide_grants_with_high_risk_scopes": n, "tenant_wide_delegated_grants": snap.apps.summary.get("tenant_wide_delegated_grants")}
    if n == 0:
        return ok(ev)
    aff = [f'{g["client_name"]}: {", ".join(g["high_risk_scopes"])}' for g in snap.apps.data.get("delegated_grants_tenant_wide", []) if g.get("high_risk_scopes")]
    return warn(ev, "Cần xác nhận từng ứng dụng là hợp lệ và cần quyền đó", affected=aff)


@rule(id="APP-007", domain="Apps", title="Người dùng được tự consent cho ứng dụng", severity="High",
      risk="Illicit consent grant: người dùng bị lừa cấp quyền cho ứng dụng độc hại qua phishing OAuth.",
      remediation=["Chuyển sang 'Do not allow user consent' hoặc chỉ cho verified publisher + quyền rủi ro thấp",
                   "Bật admin consent request workflow"],
      effort="Low", frameworks=["CIS M365 Foundations - user consent", "Microsoft - illicit consent grant"],
      sources=["apps"], needs=[("apps", "authorizationPolicy")], tags=["apps", "consent"])
def app_007(snap):
    mode = snap.apps.summary.get("user_consent_mode")
    ev = {"user_consent_mode": mode, "admin_consent_workflow_enabled": snap.apps.summary.get("admin_consent_workflow_enabled")}
    if mode in (None, "unknown"):
        return unknown("Không xác định được chế độ consent")
    if mode == "users_cannot_consent":
        if ev["admin_consent_workflow_enabled"] is False:
            return warn(ev, "Người dùng không thể consent nhưng chưa bật admin consent workflow", severity="Low")
        return ok(ev)
    if mode == "users_can_consent_low_risk_verified_publishers":
        return ok(ev, "Mức khuyến nghị của Microsoft")
    if "legacy" in mode:
        return fail(ev, "Người dùng có thể consent cho bất kỳ ứng dụng nào")
    return warn(ev, "Chính sách consent tùy chỉnh - cần rà soát thủ công", severity="Medium")


@rule(id="APP-008", domain="Apps", title="App có credential nhưng không hoạt động lâu ngày", severity="Low",
      risk="App bỏ quên còn credential hợp lệ là cửa hậu tiềm năng.",
      remediation=["Xác nhận với chủ sở hữu; vô hiệu hóa hoặc xóa app/credential"],
      effort="Low", frameworks=["Quản trị workload identity"], sources=["apps"], needs=APPS, tags=["apps", "hygiene"])
def app_008(snap):
    s = snap.apps.summary
    if not s.get("sp_activity_data_available"):
        return unknown("Không có dữ liệu hoạt động service principal (endpoint beta lỗi hoặc thiếu quyền)")
    n = s.get("apps_inactive_with_credentials")
    ev = {"apps_inactive_with_credentials": n}
    return ok(ev) if not n else warn(ev, f"{n} app không hoạt động nhưng còn credential", affected=_names(snap, "inactive_with_credentials"))
