from ..model import dig, fail, na, ok, unknown, warn
from ..registry import rule

ROLES = [("baseline", "roleAssignments")]


def _roles_summary(snap):
    return dig(snap.baseline.data, "admin_roles", "summary") or {}


def _active(snap):
    return dig(snap.baseline.data, "admin_roles", "active") or []


@rule(id="BL-001", domain="Baseline", title="Số lượng Global Administrator ngoài khoảng khuyến nghị (2-5)", severity="Medium",
      risk="Quá nhiều GA mở rộng bề mặt tấn công; chỉ 1 GA gây rủi ro mất quyền quản trị khi sự cố.",
      remediation=["Giảm GA xuống 2-4 tài khoản cloud-only (gồm break-glass)", "Chuyển quyền thấp hơn: dùng role chuyên biệt (Exchange/Intune/User Admin)"],
      effort="Low", frameworks=["CIS M365 Foundations - số lượng Global Admin"], sources=["baseline"], needs=ROLES, tags=["privileged"])
def bl_001(snap):
    n = _roles_summary(snap).get("global_admin_active_users")
    if n is None:
        return unknown("Thiếu số liệu Global Admin")
    ev = {"global_admin_active_users": n}
    if n > 5:
        return fail(ev, f"{n} Global Admin (khuyến nghị 2-5)")
    if n < 2:
        return warn(ev, f"Chỉ {n} Global Admin: cần tối thiểu 2 (gồm break-glass) để tránh khóa tenant")
    return ok(ev)


@rule(id="BL-002", domain="Baseline", title="Global Admin được gán thường trực, chưa dùng PIM (just-in-time)", severity="Medium",
      risk="Quyền thường trực làm tăng thiệt hại nếu tài khoản bị chiếm; PIM giới hạn thời gian và có phê duyệt.",
      remediation=["Chuyển GA sang eligible trong PIM, yêu cầu MFA + lý do khi kích hoạt", "Giữ lại 2 break-glass ở dạng permanent"],
      effort="Medium", frameworks=["Microsoft Entra PIM best practices"], sources=["baseline"],
      needs=ROLES + [("baseline", "roleEligibilitySchedules")], tags=["privileged", "pim"])
def bl_002(snap):
    s = _roles_summary(snap)
    active, elig, perm = s.get("global_admin_active_users"), s.get("global_admin_eligible_users"), s.get("global_admin_permanent_users")
    ev = {"global_admin_active_users": active, "global_admin_eligible_users": elig, "global_admin_permanent_users": perm}
    if active is None:
        return unknown("Thiếu số liệu")
    if elig == 0 and active > 0:
        return fail(ev, "Không có Global Admin nào ở dạng eligible: PIM chưa được sử dụng")
    if perm is not None and perm > 2:
        return warn(ev, f"{perm} Global Admin thường trực (nên chỉ giữ break-glass)")
    return ok(ev)


@rule(id="BL-003", domain="Baseline", title="Guest đang giữ vai trò quản trị", severity="High",
      risk="Tài khoản ngoài tổ chức với quyền đặc quyền nằm ngoài kiểm soát vòng đời của bạn.",
      remediation=["Gỡ vai trò đặc quyền khỏi guest", "Dùng tài khoản thành viên riêng cho quản trị viên bên ngoài, kèm PIM"],
      effort="Low", frameworks=["Quản trị truy cập đặc quyền"], sources=["baseline"], needs=ROLES, tags=["privileged", "guests"])
def bl_003(snap):
    n = _roles_summary(snap).get("privileged_guest_users")
    if n is None:
        return unknown("Thiếu số liệu")
    ev = {"privileged_guest_users": n}
    if n == 0:
        return ok(ev)
    aff = sorted({a["upn"] for a in _active(snap) if a.get("principal_type") == "user" and a.get("is_privileged") and a.get("user_type") == "Guest"})
    return fail(ev, f"{n} guest giữ vai trò đặc quyền", affected=aff)


@rule(id="BL-004", domain="Baseline", title="Tài khoản đồng bộ từ on-premises giữ vai trò đặc quyền cloud", severity="Medium",
      risk="Chiếm được AD on-premises sẽ dẫn tới chiếm quyền quản trị cloud (lateral movement).",
      remediation=["Dùng tài khoản admin cloud-only riêng, không đồng bộ từ AD"],
      effort="Medium", frameworks=["Microsoft - bảo vệ tài khoản đặc quyền hybrid"], sources=["baseline"], needs=ROLES, tags=["privileged", "hybrid"])
def bl_004(snap):
    n = _roles_summary(snap).get("privileged_onprem_synced_accounts")
    if n is None:
        return unknown("Thiếu số liệu")
    ev = {"privileged_onprem_synced_accounts": n}
    if n == 0:
        return ok(ev)
    aff = sorted({a["upn"] for a in _active(snap) if a.get("principal_type") == "user" and a.get("is_privileged") and a.get("synced_from_onprem")})
    return fail(ev, f"{n} tài khoản đặc quyền được đồng bộ từ AD", affected=aff)


@rule(id="BL-005", domain="Baseline", title="Service principal đang giữ vai trò thư mục", severity="Low",
      risk="Ứng dụng có vai trò quản trị là mục tiêu giá trị cao và thường không được giám sát.",
      remediation=["Xác minh từng ứng dụng cần vai trò đó", "Thay bằng quyền Graph tối thiểu hoặc vai trò hẹp hơn"],
      effort="Medium", frameworks=["Quản trị workload identity"], sources=["baseline"], needs=ROLES, tags=["privileged", "apps"])
def bl_005(snap):
    n = _roles_summary(snap).get("roles_held_by_service_principals")
    if n is None:
        return unknown("Thiếu số liệu")
    ev = {"roles_held_by_service_principals": n}
    if n == 0:
        return ok(ev)
    aff = sorted({f'{a.get("name")} -> {a.get("role")}' for a in _active(snap) if a.get("principal_type") == "servicePrincipal"})
    return warn(ev, "Cần xác nhận các ứng dụng này thật sự cần vai trò quản trị", affected=aff)


@rule(id="BL-006", domain="Baseline", title="Có đăng nhập legacy authentication thành công gần đây", severity="High",
      risk="Legacy auth không hỗ trợ MFA; các đăng nhập thành công cho thấy đang bị dùng (hoặc bị lạm dụng).",
      remediation=["Xác định user/ứng dụng dùng legacy (xem top_users)", "Chuyển sang modern auth rồi chặn bằng CA (CA-002)"],
      effort="Medium", frameworks=["CIS M365 Foundations - chặn legacy authentication"], sources=["baseline"], tags=["legacy-auth"])
def bl_006(snap):
    la = dig(snap.baseline.data, "legacy_auth") or {}
    if not la.get("performed"):
        return unknown("Đã bỏ qua sign-in log khi thu thập (-SkipSignInLogs)")
    errs = [e for e in snap.baseline.errors if str(e.get("name", "")).startswith("signIns")]
    by_proto = la.get("by_protocol") or []
    if errs and not by_proto:
        hints = {e.get("hint") for e in errs}
        return na("Không có sign-in log (cần Entra ID P1)") if "license" in hints else unknown("Không đọc được sign-in log (thiếu quyền AuditLog.Read.All?)")
    total = la.get("total_events_sampled", 0)
    ev = {"lookback_days": la.get("lookback_days"), "events_sampled": total, "distinct_users": la.get("distinct_users"),
          "protocols": {p["protocol"]: p["events_sampled"] for p in by_proto if p.get("events_sampled")}}
    partial = f" (một phần giao thức lỗi: {len(errs)})" if errs else ""
    if total == 0:
        return ok(ev, "Không thấy đăng nhập legacy thành công trong cửa sổ quan sát" + partial)
    aff = [u["upn"] for u in la.get("top_users", [])]
    return fail(ev, f"{total}+ sự kiện legacy thành công từ {la.get('distinct_users')} user" + partial, affected=aff)


@rule(id="BL-007", domain="Baseline", title="Microsoft Secure Score thấp", severity="Low",
      risk="Secure Score thấp cho thấy nhiều khuyến nghị bảo mật của Microsoft chưa được áp dụng (chỉ mang tính tham khảo).",
      remediation=["Xem control_scores để ưu tiên các hạng mục điểm cao, effort thấp"],
      effort="Medium", frameworks=["Microsoft Secure Score"], sources=["baseline"], needs=[("baseline", "secureScore")], tags=["score"])
def bl_007(snap):
    pct = snap.baseline.summary.get("secure_score_pct")
    if pct is None:
        return unknown("Không có Secure Score")
    ev = {"secure_score_pct": pct}
    return ok(ev) if pct >= 50 else warn(ev, f"Secure Score {pct}% (< 50%)")


@rule(id="BL-008", domain="Baseline", title="SMS/Voice vẫn được bật làm phương thức xác thực", severity="Low",
      risk="SMS/Voice dễ bị SIM-swap và phishing hơn so với Authenticator/FIDO2.",
      remediation=["Tắt SMS/Voice cho nhóm có rủi ro cao hoặc toàn tổ chức khi đã có phương thức thay thế", "Dùng authentication strengths"],
      effort="Medium", frameworks=["Microsoft Entra - authentication methods policy"], sources=["baseline"],
      needs=[("baseline", "authenticationMethodsPolicy")], tags=["auth-methods"])
def bl_008(snap):
    methods = dig(snap.baseline.data, "authentication_methods_policy", "methods") or []
    if not methods:
        return unknown("Không có dữ liệu authentication methods policy")
    on = sorted(m["id"] for m in methods if m.get("id") in ("Sms", "Voice") and m.get("state") == "enabled")
    ev = {"weak_methods_enabled": on}
    return ok(ev) if not on else warn(ev, "Đang bật: " + ", ".join(on))


@rule(id="BL-009", domain="Baseline", title="Tài khoản đã bị vô hiệu hóa vẫn giữ vai trò đặc quyền", severity="Low",
      risk="Tài khoản bị bỏ quên nhưng còn quyền; nếu bị bật lại sẽ có đặc quyền ngay.",
      remediation=["Gỡ vai trò khỏi tài khoản disabled", "Đưa vào quy trình offboarding"],
      effort="Low", frameworks=["Quản lý vòng đời tài khoản đặc quyền"], sources=["baseline"], needs=ROLES, tags=["privileged", "hygiene"])
def bl_009(snap):
    n = _roles_summary(snap).get("privileged_disabled_accounts")
    if n is None:
        return unknown("Thiếu số liệu")
    ev = {"privileged_disabled_accounts": n}
    if n == 0:
        return ok(ev)
    aff = sorted({a["upn"] for a in _active(snap) if a.get("principal_type") == "user" and a.get("is_privileged") and a.get("account_enabled") is False})
    return warn(ev, f"{n} tài khoản disabled còn vai trò đặc quyền", affected=aff)
