#Requires -Version 7.0
[CmdletBinding()]
param(
    [string]$TenantId,
    [string]$ClientId,
    [string]$OutRoot = (Join-Path $PSScriptRoot 'snapshots'),
    [string]$AuditDir = (Join-Path $PSScriptRoot 'audit-engine'),
    [switch]$Pseudonymize,
    [switch]$SkipSignInLogs,
    [switch]$IncludeNonInteractive,
    [int]$StaleDays = 90
)

Import-Module (Join-Path $PSScriptRoot 'AuditCommon.psm1') -Force -ErrorAction Stop

$ErrorActionPreference = 'Stop'

if (-not $TenantId) {
    $saved = Get-AuditSavedCredentials -ErrorAction SilentlyContinue
    if ($saved) { $TenantId = $saved.TenantId }
}
if (-not $ClientId) {
    $saved = Get-AuditSavedCredentials -ErrorAction SilentlyContinue
    if ($saved) { $ClientId = $saved.ClientId }
}

if (-not $TenantId -or -not $ClientId) {
    throw 'Thiếu TenantId hoặc ClientId. Hãy truyền tham số hoặc chạy Setup-AuditCredentials.ps1 trước.'
}

if (-not $env:M365_CLIENT_SECRET) {
    $saved = Get-AuditSavedCredentials -ErrorAction SilentlyContinue
    if ($saved -and $saved.ClientSecret) {
        $env:M365_CLIENT_SECRET = $saved.ClientSecret
    }
}

if (-not $env:M365_CLIENT_SECRET) {
    $env:M365_CLIENT_SECRET = Read-Host 'Client secret' -MaskInput
}

Write-Host '== Bước 1: Sinh snapshot mới == ' -ForegroundColor Green
& (Join-Path $PSScriptRoot 'Run-Collectors.ps1') `
    -TenantId $TenantId `
    -ClientId $ClientId `
    -OutRoot $OutRoot `
    -Pseudonymize:$Pseudonymize `
    -SkipSignInLogs:$SkipSignInLogs `
    -IncludeNonInteractive:$IncludeNonInteractive `
    -StaleDays $StaleDays

$tenantFolder = Join-Path $OutRoot $TenantId
$latestRun = (Get-ChildItem -Path $tenantFolder -Directory | Sort-Object Name -Descending | Select-Object -First 1).FullName
if (-not $latestRun) {
    throw "Không tìm thấy folder snapshot nào trong $tenantFolder"
}

$combined = Join-Path $tenantFolder 'combined-run'
New-Item -ItemType Directory -Force -Path $combined | Out-Null

$files = @(
    '01_identity.json',
    '02_conditional_access.json',
    '03_security_baseline.json',
    '04_apps.json',
    '05_licenses.json'
)

foreach ($f in $files) {
    $src = Join-Path $latestRun $f
    if (-not (Test-Path $src)) {
        throw "Thiếu file snapshot: $src"
    }
    Copy-Item -Path $src -Destination $combined -Force
}

Write-Host '== Bước 2: Đã gom 5 file JSON vào folder duy nhất == ' -ForegroundColor Green
Write-Host "Folder đầu vào: $combined"

Push-Location $AuditDir
try {
    Write-Host '== Bước 3: Chạy run_audit.py == ' -ForegroundColor Green
    python .\run_audit.py --snapshots $combined --out out
}
finally {
    Pop-Location
}
