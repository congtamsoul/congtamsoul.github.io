#Requires -Version 7.0
<#
.SYNOPSIS
  Collector 3 - Security baseline: đăng ký MFA, legacy authentication (sign-in thực tế),
  gán admin role (+ PIM nếu có), authentication methods policy, Microsoft Secure Score.
.NOTES
  Quyền Graph (Application, read-only): Reports.Read.All, AuditLog.Read.All, RoleManagement.Read.Directory,
  Directory.Read.All, Policy.Read.All, SecurityEvents.Read.All, User.Read.All
  Cần Entra ID P1 (reports/sign-in logs), P2/Governance (PIM eligible) - thiếu sẽ ghi vào mục errors.
  Sign-in log chỉ lưu ~30 ngày. Giá trị clientAppType có thể cần chỉnh theo tenant (-LegacyProtocols).
#>
[CmdletBinding()]
param(
    [string]$TenantId,
    [string]$ClientId,
    [string]$OutDir,
    [int]$LookbackDays = 7,
    [int]$MaxPagesPerProtocol = 5,
    [string[]]$LegacyProtocols = @('Exchange ActiveSync', 'IMAP4', 'POP3', 'SMTP', 'Authenticated SMTP',
        'MAPI Over HTTP', 'Other clients', 'Exchange Web Services'),
    [switch]$IncludeNonInteractive,
    [switch]$SkipSignInLogs,
    [switch]$Pseudonymize
)
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot 'AuditCommon.psm1') -ErrorAction Stop
Start-AuditCollector -TenantId $TenantId -ClientId $ClientId -OutDir $OutDir -Pseudonymize:$Pseudonymize `
    -Permissions 'Reports.Read.All', 'AuditLog.Read.All', 'RoleManagement.Read.Directory', 'Policy.Read.All', 'SecurityEvents.Read.All', 'Directory.Read.All'

Write-Host '[03] Security baseline collector...' -ForegroundColor Cyan

# =====================================================================
# A) MFA registration
# =====================================================================
$weakMethods = @('mobilePhone', 'alternateMobilePhone', 'officePhone', 'email')
$regRaw = Invoke-GraphSafe -Name 'userRegistrationDetails' -Paged -Uri '/v1.0/reports/authenticationMethods/userRegistrationDetails?$top=999'
$reg = @()
if ($null -ne $regRaw) {
    $reg = @(foreach ($r in $regRaw) {
            $methods = ConvertTo-AuditArray $r.methodsRegistered
            $nonWeak = @($methods | Where-Object { $_ -notin $weakMethods })
            [ordered]@{
                id                      = $r.id
                upn                     = Get-AuditAlias $r.userPrincipalName 'user'
                user_type               = $r.userType
                is_admin                = [bool]$r.isAdmin
                is_mfa_registered       = [bool]$r.isMfaRegistered
                is_mfa_capable          = [bool]$r.isMfaCapable
                is_sspr_registered      = [bool]$r.isSsprRegistered
                is_passwordless_capable = [bool]$r.isPasswordlessCapable
                default_mfa_method      = $r.defaultMfaMethod
                methods                 = $methods
                only_weak_methods       = ($methods.Count -gt 0 -and $nonWeak.Count -eq 0)
            }
        })
}
$regById = @{}
foreach ($r in $reg) { $regById[$r.id] = $r }

$mfaTotal = $reg.Count
$mfaDone  = @($reg | Where-Object { $_.is_mfa_registered }).Count
$mfaSummary = [ordered]@{
    available                 = ($null -ne $regRaw)
    users_total               = $mfaTotal
    mfa_registered            = $mfaDone
    mfa_registered_pct        = if ($mfaTotal -gt 0) { [math]::Round(100.0 * $mfaDone / $mfaTotal, 1) } else { $null }
    mfa_capable               = @($reg | Where-Object { $_.is_mfa_capable }).Count
    passwordless_capable      = @($reg | Where-Object { $_.is_passwordless_capable }).Count
    users_only_weak_methods   = @($reg | Where-Object { $_.only_weak_methods }).Count
    admins_total              = @($reg | Where-Object { $_.is_admin }).Count
    admins_without_mfa        = @($reg | Where-Object { $_.is_admin -and -not $_.is_mfa_registered }).Count
    sspr_registered           = @($reg | Where-Object { $_.is_sspr_registered }).Count
}

# =====================================================================
# B) Legacy authentication - sign-in thực tế thành công trong N ngày
# =====================================================================
$legacy = [ordered]@{ performed = $false; lookback_days = $LookbackDays; by_protocol = @(); top_users = @() }
if (-not $SkipSignInLogs) {
    $legacy.performed = $true
    $since = [datetime]::UtcNow.AddDays(-$LookbackDays).ToString("yyyy-MM-dd'T'HH:mm:ss'Z'")
    $modes = @('interactive')
    if ($IncludeNonInteractive) { $modes += 'nonInteractive' }

    $allEvents = [System.Collections.Generic.List[object]]::new()
    $byProto   = [System.Collections.Generic.List[object]]::new()

    foreach ($mode in $modes) {
        $root = '/v1.0/auditLogs/signIns'
        $filterParts = @("createdDateTime ge $since")
        if ($mode -eq 'nonInteractive') {
            $root = '/beta/auditLogs/signIns'   # non-interactive chỉ có ở beta
            $filterParts += "signInEventTypes/any(t: t eq 'nonInteractiveUser')"
        }
        $filter = ($filterParts -join ' and ')
        $uri = '{0}?$filter={1}&$select=createdDateTime,userPrincipalName,appDisplayName,clientAppUsed,status&$top=100' -f $root, [uri]::EscapeDataString($filter)
        $ev = Invoke-GraphSafe -Name "signIns[$mode]" -Paged -MaxPages $MaxPagesPerProtocol -Uri $uri
        $truncated = Get-AuditLastTruncated
        if ($null -eq $ev) { continue }

        $successful = @($ev | Where-Object { $_.status -and $_.status.errorCode -eq 0 })

        foreach ($proto in $LegacyProtocols) {
            $filtered = @($successful | Where-Object { $_.clientAppUsed -eq $proto })
            foreach ($e in $filtered) {
                $allEvents.Add([pscustomobject]@{ proto = $proto; mode = $mode; upn = $e.userPrincipalName; app = $e.appDisplayName })
            }
            $users = @($filtered | ForEach-Object { $_.userPrincipalName } | Sort-Object -Unique)
            $byProto.Add([ordered]@{
                    protocol       = $proto
                    mode           = $mode
                    events_sampled = $filtered.Count
                    truncated      = $truncated   # true = còn nhiều hơn số sự kiện đã lấy
                    distinct_users = $users.Count
                    top_apps       = @($filtered | Group-Object { $_.appDisplayName } | Sort-Object Count -Descending | Select-Object -First 5 |
                            ForEach-Object { [ordered]@{ app = $_.Name; count = $_.Count } })
                })
        }
    }
    $legacy.by_protocol = @($byProto)
    $legacy.top_users = @($allEvents | Group-Object upn | Sort-Object Count -Descending | Select-Object -First 20 | ForEach-Object {
            [ordered]@{
                upn       = Get-AuditAlias $_.Name 'user'
                events    = $_.Count
                protocols = @($_.Group | ForEach-Object { $_.proto } | Sort-Object -Unique)
            }
        })
    $legacy.total_events_sampled = $allEvents.Count
    $legacy.distinct_users       = @($allEvents | ForEach-Object { $_.upn } | Sort-Object -Unique).Count
}

# =====================================================================
# C) Admin roles
# =====================================================================
$privilegedNames = @('Global Administrator', 'Privileged Role Administrator', 'Privileged Authentication Administrator',
    'Security Administrator', 'Exchange Administrator', 'SharePoint Administrator', 'User Administrator',
    'Application Administrator', 'Cloud Application Administrator', 'Conditional Access Administrator',
    'Authentication Administrator', 'Helpdesk Administrator', 'Intune Administrator', 'Teams Administrator',
    'Hybrid Identity Administrator', 'Billing Administrator', 'Compliance Administrator')

$roleDefs = Invoke-GraphSafe -Name 'roleDefinitions' -Paged -Uri '/v1.0/roleManagement/directory/roleDefinitions'
$assign   = Invoke-GraphSafe -Name 'roleAssignments' -Paged -Uri '/v1.0/roleManagement/directory/roleAssignments?$expand=principal'
$elig     = Invoke-GraphSafe -Name 'roleEligibilitySchedules' -Paged -Uri '/v1.0/roleManagement/directory/roleEligibilitySchedules?$expand=principal'
$inst     = Invoke-GraphSafe -Name 'roleAssignmentScheduleInstances' -Paged -Uri '/v1.0/roleManagement/directory/roleAssignmentScheduleInstances?$expand=principal'

$defMap = @{}
if ($null -ne $roleDefs) {
    foreach ($d in $roleDefs) {
        $defMap[$d.id] = @{ name = $d.displayName; privileged = ([bool]$d.isPrivileged -or ($d.displayName -in $privilegedNames)) }
    }
}
$userById = @{}
foreach ($u in (Get-AuditUsers)) { $userById[$u.id] = $u }

function New-RoleRecord {
    param($Item, [string]$Kind)
    $pr   = $Item.principal
    $type = ("$($pr.'@odata.type')" -replace '^#microsoft\.graph\.', '')
    $def  = $defMap[$Item.roleDefinitionId]
    $rec  = [ordered]@{
        kind            = $Kind      # active | eligible
        role            = $def.name
        is_privileged   = [bool]$def.privileged
        role_definition_id = $Item.roleDefinitionId
        principal_id    = $Item.principalId
        principal_type  = $type
        directory_scope = $Item.directoryScopeId
        member_type     = $Item.memberType
        assignment_type = $Item.assignmentType
        end_date_time   = if ($Item.endDateTime) { $Item.endDateTime } else { $Item.scheduleInfo.expiration.endDateTime }
    }
    if ($type -eq 'user') {
        $u = $userById[$Item.principalId]
        $rec.upn                = Get-AuditAlias $pr.userPrincipalName 'user'
        $rec.account_enabled    = if ($u) { [bool]$u.accountEnabled } else { $null }
        $rec.user_type          = if ($u) { $u.userType } else { $null }
        $rec.synced_from_onprem = if ($u) { [bool]$u.onPremisesSyncEnabled } else { $null }
        $rec.mfa_registered     = if ($regById.ContainsKey($Item.principalId)) { $regById[$Item.principalId].is_mfa_registered } else { $null }
    }
    else {
        $rec.name = $pr.displayName
    }
    $rec
}

# Ưu tiên schedule instances (phân biệt Assigned vs Activated, có endDateTime); không có thì dùng roleAssignments
$activeSource = if ($null -ne $inst -and $inst.Count -gt 0) { $inst } else { $assign }
$activeUsingInstances = ($null -ne $inst -and $inst.Count -gt 0)
$active   = @(); if ($null -ne $activeSource) { $active = @($activeSource | ForEach-Object { New-RoleRecord $_ 'active' }) }
$eligible = @(); if ($null -ne $elig) { $eligible = @($elig | ForEach-Object { New-RoleRecord $_ 'eligible' }) }

$activeUsers   = @($active | Where-Object { $_.principal_type -eq 'user' })
$privActive    = @($activeUsers | Where-Object { $_.is_privileged })
$gaActive      = @($activeUsers | Where-Object { $_.role -eq 'Global Administrator' })
$gaEligible    = @($eligible | Where-Object { $_.principal_type -eq 'user' -and $_.role -eq 'Global Administrator' })
$permanentGA   = @($gaActive | Where-Object { $_.assignment_type -eq 'Assigned' -and -not $_.end_date_time })

$byRole = @(foreach ($grp in ($active | Group-Object { $_.role } | Sort-Object Count -Descending)) {
        $rn = $grp.Name
        [ordered]@{ role = $rn; active = $grp.Count; eligible = @($eligible | Where-Object { $_.role -eq $rn }).Count }
    })

$roles = [ordered]@{
    assignments_source                = if ($activeUsingInstances) { 'roleAssignmentScheduleInstances' } else { 'roleAssignments' }
    pim_eligible_data_available       = ($null -ne $elig)
    active_assignments_total          = $active.Count
    eligible_assignments_total        = $eligible.Count
    global_admin_active_users         = Get-AuditUniqueCount $gaActive 'principal_id'
    global_admin_permanent_users      = if ($activeUsingInstances) { Get-AuditUniqueCount $permanentGA 'principal_id' } else { $null }
    global_admin_eligible_users       = Get-AuditUniqueCount $gaEligible 'principal_id'
    privileged_active_users           = Get-AuditUniqueCount $privActive 'principal_id'
    privileged_users_without_mfa      = Get-AuditUniqueCount @($privActive | Where-Object { $_.mfa_registered -eq $false }) 'principal_id'
    privileged_guest_users            = Get-AuditUniqueCount @($privActive | Where-Object { $_.user_type -eq 'Guest' }) 'principal_id'
    privileged_disabled_accounts      = Get-AuditUniqueCount @($privActive | Where-Object { $_.account_enabled -eq $false }) 'principal_id'
    privileged_onprem_synced_accounts = Get-AuditUniqueCount @($privActive | Where-Object { $_.synced_from_onprem -eq $true }) 'principal_id'
    roles_held_by_service_principals  = @($active | Where-Object { $_.principal_type -eq 'servicePrincipal' }).Count
    roles_held_by_groups              = @($active | Where-Object { $_.principal_type -eq 'group' }).Count
    by_role                           = $byRole
}

# =====================================================================
# D) Authentication methods policy + E) Secure Score
# =====================================================================
$amp = Invoke-GraphSafe -Name 'authenticationMethodsPolicy' -Uri '/v1.0/policies/authenticationMethodsPolicy'
$authMethods = $null
if ($amp) {
    $cfgs = ConvertTo-AuditArray $amp.authenticationMethodConfigurations
    $authMethods = [ordered]@{
        registration_campaign_state = $amp.registrationEnforcement.authenticationMethodsRegistrationCampaign.state
        methods = @($cfgs | ForEach-Object { [ordered]@{ id = $_.id; state = $_.state } })
    }
}

$score = Select-AuditSingle (Invoke-GraphSafe -Name 'secureScore' -Uri '/v1.0/security/secureScores?$top=1')
$secureScore = $null
if ($score) {
    $ctrls = ConvertTo-AuditArray $score.controlScores
    $secureScore = [ordered]@{
        created_at    = $score.createdDateTime
        current_score = $score.currentScore
        max_score     = $score.maxScore
        pct           = if ($score.maxScore) { [math]::Round(100.0 * $score.currentScore / $score.maxScore, 1) } else { $null }
        enabled_services = $score.enabledServices
        average_comparative_scores = $score.averageComparativeScores
        control_scores = @($ctrls | ForEach-Object { [ordered]@{ name = $_.controlName; category = $_.controlCategory; score = $_.score } })
    }
}

# =====================================================================
$summary = [ordered]@{
    mfa                  = $mfaSummary
    legacy_auth          = [ordered]@{
        sign_in_logs_checked = $legacy.performed
        events_sampled       = $legacy.total_events_sampled
        distinct_users       = $legacy.distinct_users
    }
    admin_roles          = [ordered]@{
        global_admin_active_users    = $roles.global_admin_active_users
        global_admin_permanent_users = $roles.global_admin_permanent_users
        privileged_users_without_mfa = $roles.privileged_users_without_mfa
        privileged_guest_users       = $roles.privileged_guest_users
        privileged_onprem_synced_accounts = $roles.privileged_onprem_synced_accounts
    }
    secure_score_pct     = if ($secureScore) { $secureScore.pct } else { $null }
}
$data = [ordered]@{
    mfa_registration       = [ordered]@{ summary = $mfaSummary; users = $reg }
    legacy_auth            = $legacy
    admin_roles            = [ordered]@{ summary = $roles; active = $active; eligible = $eligible }
    authentication_methods_policy = $authMethods
    secure_score           = $secureScore
}
$notes = @(
    'is_mfa_registered chỉ cho biết user đã đăng ký MFA, KHÔNG chứng minh MFA được bắt buộc - đối chiếu với snapshot 02.',
    'legacy_auth chỉ lấy mẫu sign-in thành công trong LookbackDays (mặc định 7) và tối đa MaxPagesPerProtocol trang/giao thức; truncated=true nghĩa là còn nhiều hơn.',
    'Mặc định chỉ quét sign-in interactive (v1.0). Legacy protocol thường là non-interactive: thêm -IncludeNonInteractive (beta) để đầy đủ hơn.',
    'Nếu roleAssignmentScheduleInstances lỗi (thiếu license), admin_roles dùng roleAssignments và không phân biệt được permanent/time-bound.',
    'Chưa mở rộng nhóm (group) giữ role: principal_type=group cần đọc members riêng.'
)
$result = Save-AuditSnapshot -Domain 'SecurityBaseline' -Name '03_security_baseline' -Data $data -Summary $summary -Notes $notes `
    -Sources @('/v1.0/reports/authenticationMethods/userRegistrationDetails', '/v1.0/auditLogs/signIns',
    '/v1.0/roleManagement/directory/*', '/v1.0/policies/authenticationMethodsPolicy', '/v1.0/security/secureScores')
Write-Host ("    -> MFA {0}% | GA active: {1} | admin không MFA: {2} | {3} lỗi/cảnh báo" -f `
        $mfaSummary.mfa_registered_pct, $roles.global_admin_active_users, $roles.privileged_users_without_mfa, $result.ErrorCount)
$result
