#Requires -Version 7.0
<#
.SYNOPSIS
  Collector 5 - Licenses: SKU đã mua/đã gán/còn trống, license trên tài khoản bất hoạt/bị vô hiệu/guest,
  người dùng giữ nhiều SKU chồng lấp.
.NOTES
  Quyền Graph (Application, read-only): User.Read.All, Organization.Read.All (hoặc LicenseAssignment.Read.All),
  AuditLog.Read.All (signInActivity - cần Entra P1).
  Script KHÔNG tính tiền (giá thay đổi theo hợp đồng) - chỉ đếm số lượng để lên kế hoạch tối ưu.
#>
[CmdletBinding()]
param(
    [string]$TenantId,
    [string]$ClientId,
    [string]$OutDir,
    [int]$StaleDays = 90,
    [switch]$Pseudonymize
)
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot 'AuditCommon.psm1') -ErrorAction Stop
Start-AuditCollector -TenantId $TenantId -ClientId $ClientId -OutDir $OutDir -Pseudonymize:$Pseudonymize `
    -Permissions 'User.Read.All', 'Organization.Read.All', 'AuditLog.Read.All'

Write-Host '[05] License collector...' -ForegroundColor Cyan

# Tên thân thiện cho các SKU phổ biến (không có trong map thì dùng skuPartNumber)
$friendly = @{
    'SPE_E3' = 'Microsoft 365 E3'; 'SPE_E5' = 'Microsoft 365 E5'; 'SPE_F1' = 'Microsoft 365 F3'
    'ENTERPRISEPACK' = 'Office 365 E3'; 'ENTERPRISEPREMIUM' = 'Office 365 E5'; 'STANDARDPACK' = 'Office 365 E1'
    'O365_BUSINESS_ESSENTIALS' = 'Microsoft 365 Business Basic'; 'O365_BUSINESS_PREMIUM' = 'Microsoft 365 Business Standard'
    'SPB' = 'Microsoft 365 Business Premium'; 'EMS' = 'Enterprise Mobility + Security E3'; 'EMSPREMIUM' = 'Enterprise Mobility + Security E5'
    'AAD_PREMIUM' = 'Entra ID P1'; 'AAD_PREMIUM_P2' = 'Entra ID P2'; 'POWER_BI_PRO' = 'Power BI Pro'
    'FLOW_FREE' = 'Power Automate Free'; 'POWER_BI_STANDARD' = 'Power BI (free)'
    'WINDOWS_STORE' = 'Windows Store for Business'; 'INTUNE_A' = 'Intune Plan 1'
    'Microsoft_365_Copilot' = 'Microsoft 365 Copilot'; 'TEAMS_EXPLORATORY' = 'Teams Exploratory'
}

$skus = Invoke-GraphSafe -Name 'subscribedSkus' -Paged -Uri '/v1.0/subscribedSkus'
if ($null -eq $skus) { $skus = @() }

$rawUsers = Get-AuditUsers
$users    = @($rawUsers | ForEach-Object { ConvertTo-AuditUserRecord $_ })
$signInOk = Test-AuditSignInActivity

function Test-StaleUser($u, [int]$days) {
    if (-not $u.account_enabled) { return $false }
    if ($null -ne $u.days_since_last_sign_in) { return ($u.days_since_last_sign_in -gt $days) }
    return ($null -ne $u.days_since_created -and $u.days_since_created -gt $days)
}

$skuName = @{}      # skuId -> friendly/partNumber
foreach ($s in $skus) {
    $skuName[$s.skuId] = if ($friendly.ContainsKey($s.skuPartNumber)) { $friendly[$s.skuPartNumber] } else { $s.skuPartNumber }
}
$licensed = @($users | Where-Object { $_.license_count -gt 0 })

# ---- Từng SKU ----
$skuRecords = @(foreach ($s in $skus) {
        $assigned = @($licensed | Where-Object { $s.skuId -in $_.sku_ids })
        $enabledUnits = [int]$s.prepaidUnits.enabled
        $consumed     = [int]$s.consumedUnits
        $plans        = ConvertTo-AuditArray $s.servicePlans
        $inactive     = @(); if ($signInOk) { $inactive = @($assigned | Where-Object { Test-StaleUser $_ $StaleDays }) }
        [ordered]@{
            sku_id             = $s.skuId
            sku_part_number    = $s.skuPartNumber
            name               = $skuName[$s.skuId]
            status             = $s.capabilityStatus
            purchased_units    = $enabledUnits
            suspended_units    = [int]$s.prepaidUnits.suspended
            warning_units      = [int]$s.prepaidUnits.warning
            consumed_units     = $consumed
            available_units    = ($enabledUnits - $consumed)
            utilization_pct    = if ($enabledUnits -gt 0) { [math]::Round(100.0 * $consumed / $enabledUnits, 1) } else { $null }
            assigned_users_seen = $assigned.Count
            assigned_to_inactive_users = if ($signInOk) { $inactive.Count } else { $null }
            assigned_to_disabled_users = @($assigned | Where-Object { -not $_.account_enabled }).Count
            assigned_to_guests         = @($assigned | Where-Object { $_.user_type -eq 'Guest' }).Count
            service_plans_count = (Get-AuditCount $s.servicePlans)
            service_plans      = @($plans | ForEach-Object { $_.servicePlanName })
        }
    })

# ---- Danh sách cần xem xét thu hồi license (chỉ user có cờ) ----
$flagged = @(foreach ($u in $licensed) {
        $reasons = @()
        if (-not $u.account_enabled)                                  { $reasons += 'account_disabled' }
        if ($signInOk -and (Test-StaleUser $u $StaleDays))             { $reasons += "inactive_over_${StaleDays}_days" }
        if ($u.user_type -eq 'Guest')                                  { $reasons += 'guest_with_license' }
        if ($reasons.Count -eq 0) { continue }
        [ordered]@{
            id                      = $u.id
            upn                     = $u.upn
            user_type               = $u.user_type
            account_enabled         = $u.account_enabled
            days_since_last_sign_in = $u.days_since_last_sign_in
            licenses                = @($u.sku_ids | ForEach-Object { $skuName[$_] })
            reasons                 = $reasons
        }
    })

# ---- Chồng lấp SKU (user giữ >= 2 SKU) ----
$multi = @($licensed | Where-Object { $_.sku_ids.Count -ge 2 })
$combos = @($multi | Group-Object { (@($_.sku_ids | ForEach-Object { $skuName[$_] }) | Sort-Object) -join ' + ' } |
        Sort-Object Count -Descending | Select-Object -First 15 |
        ForEach-Object { [ordered]@{ combination = $_.Name; users = $_.Count } })

$totalPurchased = ($skuRecords | ForEach-Object { $_.purchased_units } | Measure-Object -Sum).Sum
$summary = [ordered]@{
    skus_total                    = $skuRecords.Count
    users_total                   = $users.Count
    licensed_users                = $licensed.Count
    unlicensed_enabled_members    = @($users | Where-Object { $_.account_enabled -and $_.user_type -eq 'Member' -and $_.license_count -eq 0 }).Count
    sign_in_activity_available    = $signInOk
    stale_days_threshold          = $StaleDays
    licensed_inactive_users       = if ($signInOk) { @($licensed | Where-Object { Test-StaleUser $_ $StaleDays }).Count } else { $null }
    licensed_disabled_users       = @($licensed | Where-Object { -not $_.account_enabled }).Count
    licensed_guests               = @($licensed | Where-Object { $_.user_type -eq 'Guest' }).Count
    users_with_multiple_skus      = $multi.Count
    purchased_units_all_skus      = $totalPurchased
    available_units_paid_skus     = (@($skuRecords | Where-Object { $_.purchased_units -gt 0 -and $_.available_units -gt 0 } | ForEach-Object { $_.available_units }) | Measure-Object -Sum).Sum
    skus_with_low_utilization     = @($skuRecords | Where-Object { $null -ne $_.utilization_pct -and $_.purchased_units -ge 5 -and $_.utilization_pct -lt 80 }).Count
    skus_suspended_or_warning     = @($skuRecords | Where-Object { $_.suspended_units -gt 0 -or $_.warning_units -gt 0 -or $_.status -ne 'Enabled' }).Count
}

$data = [ordered]@{
    skus                      = $skuRecords
    licenses_to_review        = $flagged
    multi_sku_combinations    = $combos
}
$notes = @(
    'Chỉ đếm số lượng, không tính tiền; ghép với bảng giá/hợp đồng của khách ở bước báo cáo.',
    'purchased_units dựa trên prepaidUnits.enabled; trial và license miễn phí có thể làm số liệu "available" gây hiểu nhầm.',
    'License gán qua group không phân biệt trực tiếp/qua group ở bản này (cần licenseAssignmentStates).',
    'Chồng lấp SKU (ví dụ E3 + E5) có thể là chủ ý (add-on); cần người xác nhận trước khi thu hồi.',
    'Chưa phân tích việc dùng thực tế từng service plan (ví dụ tính năng E5 có dùng không) - hướng mở rộng.'
)
$result = Save-AuditSnapshot -Domain 'Licenses' -Name '05_licenses' -Data $data -Summary $summary -Notes $notes `
    -Sources @('/v1.0/subscribedSkus', '/v1.0/users')
Write-Host ("    -> {0} SKU, {1} user có license, {2} cần xem xét, {3} lỗi/cảnh báo" -f `
        $summary.skus_total, $summary.licensed_users, $flagged.Count, $result.ErrorCount)
$result
